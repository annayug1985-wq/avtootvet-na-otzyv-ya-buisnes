from uuid import uuid4

import pytest

from apps.backend.app.config.settings import Settings
from apps.backend.app.db.models.moderation_job import ModerationJob
from apps.backend.app.db.models.review import Review
from apps.backend.app.providers import OllamaProvider, OpenAIProvider, build_ai_provider
from apps.backend.app.providers.base import AiProviderQualityError, BaseAiProvider
from apps.backend.app.services.ai_service import AiService


class BadReplyProvider(BaseAiProvider):
    def __init__(self, reply: str) -> None:
        self.reply = reply

    def generate_reply(
        self,
        *,
        review_text: str,
        rating: int,
        prompt: str,
        examples: list[dict[str, str | int | None]],
        previous_reply: str | None = None,
    ) -> str:
        return self.reply


def build_review_and_job() -> tuple[Review, ModerationJob]:
    review = Review(
        id=uuid4(),
        review_key="rk",
        source="browser",
        account_id="account_1",
        author="Ivan",
        rating=5,
        review_text="Все отлично",
        address="Москва",
        review_date="2026-06-18",
        page_url="https://example.com/review/1",
        status="generating",
    )
    job = ModerationJob(
        id=uuid4(),
        review_id=review.id,
        status="generating",
        generated_reply=None,
    )
    return review, job


def test_build_ai_provider_uses_settings() -> None:
    assert isinstance(build_ai_provider(Settings(ai_provider="ollama")), OllamaProvider)
    assert isinstance(build_ai_provider(Settings(ai_provider="openai")), OpenAIProvider)


def test_ai_service_rejects_placeholder_reply(db_session) -> None:
    review, job = build_review_and_job()
    service = AiService(db_session, provider=BadReplyProvider("{review_text}"))

    with pytest.raises(AiProviderQualityError):
        service.generate_reply_for(review=review, job=job)


def test_ai_service_rejects_template_heavy_reply(db_session) -> None:
    review, job = build_review_and_job()
    service = AiService(
        db_session,
        provider=BadReplyProvider(
            "Ваше мнение важно для нас. Мы ценим каждого клиента и будем рады видеть вас снова."
        ),
    )

    with pytest.raises(AiProviderQualityError):
        service.generate_reply_for(review=review, job=job)


def test_ai_service_rejects_markdown_list_reply(db_session) -> None:
    review, job = build_review_and_job()
    service = AiService(
        db_session,
        provider=BadReplyProvider("- Спасибо за отзыв\n- Будем рады помочь снова"),
    )

    with pytest.raises(AiProviderQualityError):
        service.generate_reply_for(review=review, job=job)


def test_ai_service_rejects_non_russian_reply(db_session) -> None:
    review, job = build_review_and_job()
    service = AiService(
        db_session,
        provider=BadReplyProvider("Thank you for your review and your trust in our company."),
    )

    with pytest.raises(AiProviderQualityError):
        service.generate_reply_for(review=review, job=job)


def test_ai_service_accepts_normal_russian_reply(db_session) -> None:
    review, job = build_review_and_job()
    service = AiService(
        db_session,
        provider=BadReplyProvider("Спасибо за отзыв. Рады, что у вас осталось хорошее впечатление о визите."),
    )

    result = service.generate_reply_for(review=review, job=job)
    assert "Спасибо за отзыв" in result
    assert 'С уважением, ГК "Альянс Тракс".' in result


def test_ai_service_normalizes_existing_signature(db_session) -> None:
    review, job = build_review_and_job()
    service = AiService(
        db_session,
        provider=BadReplyProvider('Спасибо за отзыв! С уважением, ГК "Альянс Тракс"'),
    )

    result = service.generate_reply_for(review=review, job=job)
    assert result.endswith('С уважением, ГК "Альянс Тракс".')


def test_ai_service_normalizes_digit_glued_to_word_and_adds_signature(db_session) -> None:
    review, job = build_review_and_job()
    service = AiService(
        db_session,
        provider=BadReplyProvider("Очень рады высокой оценке1"),
    )

    result = service.generate_reply_for(review=review, job=job)
    assert "оценке 1" in result
    assert result.endswith('С уважением, ГК "Альянс Тракс".')
