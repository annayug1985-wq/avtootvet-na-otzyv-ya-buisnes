from time import perf_counter
from uuid import uuid4

from fastapi import FastAPI, Request

from apps.backend.app.api.health import router as health_router
from apps.backend.app.api.jobs import router as jobs_router
from apps.backend.app.api.reviews import router as reviews_router
from apps.backend.app.api.telegram import router as telegram_router
from apps.backend.app.config.settings import get_settings
from apps.backend.app.utils import configure_logging, get_logger, reset_request_id, set_request_id

settings = get_settings()
configure_logging(settings.log_level)
logger = get_logger("reviews.api")

app = FastAPI(title="Reviews Automation Bot")


@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
    request_id = request.headers.get("x-request-id") or str(uuid4())
    token = set_request_id(request_id)
    started_at = perf_counter()
    logger.info(
        "request_started",
        extra={"request_id": request_id, "method": request.method, "path": request.url.path},
    )
    try:
        response = await call_next(request)
    except Exception:
        logger.exception(
            "request_failed",
            extra={"request_id": request_id, "method": request.method, "path": request.url.path},
        )
        raise
    finally:
        reset_request_id(token)

    duration_ms = round((perf_counter() - started_at) * 1000, 2)
    response.headers["x-request-id"] = request_id
    logger.info(
        "request_completed",
        extra={
            "request_id": request_id,
            "method": request.method,
            "path": request.url.path,
            "status_code": response.status_code,
            "duration_ms": duration_ms,
        },
    )
    return response


app.include_router(health_router)
app.include_router(reviews_router)
app.include_router(jobs_router)
app.include_router(telegram_router)
