from __future__ import annotations

import json
from urllib import request
from urllib.error import HTTPError, URLError

from apps.backend.app.config.settings import Settings
from apps.backend.app.providers.base import (
    AiProviderAuthError,
    AiProviderRateLimitError,
    AiProviderResponseError,
    AiProviderTransientError,
    BaseAiProvider,
)
from apps.backend.app.utils import call_with_retry, get_logger


class YandexGptProvider(BaseAiProvider):
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.logger = get_logger("reviews.ai.yandexgpt")

    def generate_reply(
        self,
        *,
        review_text: str,
        rating: int,
        prompt: str,
        examples: list[dict[str, str | int | None]],
        previous_reply: str | None = None,
    ) -> str:
        if not self.settings.yandexgpt_api_key or not self.settings.yandexgpt_folder_id:
            raise AiProviderAuthError("YANDEXGPT_API_KEY or YANDEXGPT_FOLDER_ID is not configured")

        payload = {
            "modelUri": f"gpt://{self.settings.yandexgpt_folder_id}/yandexgpt-lite/latest",
            "completionOptions": {"stream": False, "temperature": 0.3, "maxTokens": "400"},
            "messages": [{"role": "user", "text": prompt}],
        }
        body = json.dumps(payload).encode("utf-8")
        req = request.Request(
            url=self.settings.yandexgpt_api_base,
            data=body,
            headers={
                "Authorization": f"Api-Key {self.settings.yandexgpt_api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        def do_request():
            try:
                with request.urlopen(req, timeout=self.settings.ollama_timeout_seconds) as response:
                    return json.loads(response.read().decode("utf-8"))
            except HTTPError as exc:
                if exc.code in {401, 403}:
                    raise AiProviderAuthError("YandexGPT authentication failed") from exc
                if exc.code == 429:
                    raise AiProviderRateLimitError("YandexGPT rate limit") from exc
                if exc.code >= 500:
                    raise AiProviderTransientError("YandexGPT upstream error") from exc
                raise AiProviderResponseError(f"YandexGPT request failed with {exc.code}") from exc
            except URLError as exc:
                raise AiProviderTransientError("YandexGPT network error") from exc

        data = call_with_retry(
            do_request,
            attempts=self.settings.external_request_max_retries + 1,
            backoff_seconds=self.settings.external_request_backoff_seconds,
            retry_on=(AiProviderTransientError, AiProviderRateLimitError),
            logger=self.logger,
            operation_name="yandexgpt_generate",
        )
        alternatives = data.get("result", {}).get("alternatives", [])
        reply = str(alternatives[0].get("message", {}).get("text", "") if alternatives else "").strip()
        if not reply:
            raise AiProviderResponseError("YandexGPT returned an empty response")
        return reply
