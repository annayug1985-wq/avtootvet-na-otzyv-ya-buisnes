from __future__ import annotations

import json
from typing import Any
from urllib import request
from urllib.error import HTTPError, URLError
from uuid import UUID

from sqlalchemy.orm import Session

from apps.backend.app.config.settings import get_settings
from apps.backend.app.repositories.ai_task_repository import AiTaskRepository
from apps.backend.app.repositories.moderation_repository import ModerationRepository
from apps.backend.app.repositories.review_repository import ReviewRepository
from apps.backend.app.repositories.telegram_event_repository import TelegramEventRepository
from apps.backend.app.services.queue_service import QueueService
from apps.backend.app.utils import call_with_retry, get_logger


class TelegramService:
    CARD_SEPARATOR = "━━━━━━━━━━━━━━━"

    def __init__(self, db: Session) -> None:
        self.db = db
        self.settings = get_settings()
        self.logger = get_logger("reviews.telegram")
        self.moderation_repository = ModerationRepository(db)
        self.review_repository = ReviewRepository(db)
        self.ai_task_repository = AiTaskRepository(db)
        self.telegram_event_repository = TelegramEventRepository(db)
        self.queue_service = QueueService(self.settings)

    def send_for_moderation(self, *, job_id: UUID) -> bool:
        if not self.settings.telegram_bot_token or not self.settings.telegram_chat_id:
            self.logger.info("telegram_delivery_skipped", extra={"job_id": job_id, "reason": "telegram_not_configured"})
            return False

        job = self.moderation_repository.get(job_id)
        if job is None:
            raise ValueError(f"Moderation job {job_id} not found")

        review = self.review_repository.get(job.review_id)
        if review is None:
            raise ValueError(f"Review {job.review_id} not found")

        if job.status != "pending_review":
            self.logger.info("telegram_delivery_skipped", extra={"job_id": job_id, "reason": "job_not_pending_review"})
            return False
        if self.telegram_event_repository.has_action_for_job(job_id=job.id, action="sent_for_moderation"):
            self.logger.info("telegram_delivery_skipped", extra={"job_id": job_id, "reason": "already_sent"})
            return False
        if self.moderation_repository.has_active_delivery_for_account(review.account_id):
            self.logger.info(
                "telegram_delivery_skipped",
                extra={"job_id": job_id, "account_id": review.account_id, "reason": "account_has_active_moderation"},
            )
            return False

        payload = {
            "chat_id": self.settings.telegram_chat_id,
            "text": self._format_moderation_message(job_id=job.id, review=review, reply=job.generated_reply or ""),
            "reply_markup": self._build_inline_keyboard(job.id),
        }
        self._telegram_api("sendMessage", payload)
        self.telegram_event_repository.add_event(
            action="sent_for_moderation",
            payload=payload,
            job_id=job.id,
        )
        self.logger.info("telegram_sent", extra={"job_id": job.id, "destination": "chat"})

        if self.settings.telegram_channel_id:
            channel_payload = {
                "chat_id": self.settings.telegram_channel_id,
                "text": payload["text"],
            }
            self._telegram_api("sendMessage", channel_payload)
            self.telegram_event_repository.add_event(
                action="sent_channel_copy",
                payload=channel_payload,
                job_id=job.id,
            )
            self.logger.info("telegram_sent", extra={"job_id": job.id, "destination": "channel"})

        self.db.commit()
        return True

    def dispatch_next_pending_for_account(self, account_id: str) -> dict[str, Any]:
        next_job = self.moderation_repository.get_next_pending_for_account(account_id)
        if next_job is None:
            return {"ok": True, "handled": False, "reason": "queue_empty"}
        sent = self.send_for_moderation(job_id=next_job.id)
        return {"ok": True, "handled": sent, "jobId": str(next_job.id) if sent else None}

    def handle_update(self, update: dict[str, Any]) -> dict[str, Any]:
        update_id = self._extract_update_id(update)
        jobs_to_enqueue: list[UUID] = []
        if update_id is not None:
            existing = self.telegram_event_repository.get_by_update_id(update_id)
            if existing is not None:
                self.logger.info("telegram_duplicate_update", extra={"telegram_update_id": update_id})
                return {"ok": True, "duplicate": True}

        try:
            callback_query = update.get("callback_query")
            if isinstance(callback_query, dict):
                result = self._handle_callback_query(
                    callback_query,
                    update=update,
                    update_id=update_id,
                    jobs_to_enqueue=jobs_to_enqueue,
                )
                self.db.commit()
                for job_id in jobs_to_enqueue:
                    self.queue_service.enqueue_ai_job(job_id)
                return result

            message = update.get("message")
            if isinstance(message, dict):
                result = self._handle_message(message, update=update, update_id=update_id)
                self.db.commit()
                return result

            self.telegram_event_repository.add_event(
                action="ignored_update",
                payload=update,
                telegram_update_id=update_id,
            )
            self.db.commit()
            self.logger.info("telegram_action_received", extra={"telegram_update_id": update_id, "action": "ignored_update"})
            return {"ok": True, "handled": False}
        except Exception as exc:
            self.db.rollback()
            self.telegram_event_repository.add_event(
                action="update_error",
                payload={"update": update, "error": str(exc)},
                telegram_update_id=update_id,
            )
            self.db.commit()
            self.logger.exception("telegram_update_error", extra={"telegram_update_id": update_id})
            return {"ok": True, "handled": False, "error": str(exc)}

    def _handle_callback_query(
        self,
        callback_query: dict[str, Any],
        *,
        update: dict[str, Any],
        update_id: str | None,
        jobs_to_enqueue: list[UUID],
    ) -> dict[str, Any]:
        data = str(callback_query.get("data", ""))
        action, job_id = self._parse_callback_data(data)
        actor = self._extract_actor(callback_query.get("from"))

        self.telegram_event_repository.add_event(
            action=action,
            payload=update,
            job_id=job_id,
            telegram_update_id=update_id,
        )
        self.logger.info(
            "telegram_action_received",
            extra={"telegram_update_id": update_id, "action": action, "job_id": job_id},
        )

        if action == "approve":
            job = self._require_job(job_id)
            if not self._can_transition(job.status, expected_status="pending_review"):
                return {"ok": True, "action": action, "jobId": str(job.id), "handled": False, "reason": "job_not_pending_review"}
            approved_reply = job.approved_reply or job.generated_reply
            if not approved_reply:
                raise ValueError(f"Moderation job {job_id} does not have a reply to approve")
            self.moderation_repository.update_approved_reply(
                job,
                reply=approved_reply,
                approved_by=actor,
                status="approved",
            )
            review = self._require_review(job.review_id)
            review.status = "approved"
            self._send_resolution_message(
                title="Ответ согласован",
                body_lines=[
                    "Ответ сохранён и готов к публикации в Яндекс Бизнес.",
                    approved_reply,
                ],
                follow_up_job_id=job.id,
            )
            self.logger.info("reply_approved", extra={"job_id": job.id, "approved_by": actor})
            return {"ok": True, "action": action, "jobId": str(job.id)}

        if action == "rewrite":
            job = self._require_job(job_id)
            if not self._can_transition(job.status, expected_status="pending_review"):
                return {"ok": True, "action": action, "jobId": str(job.id), "handled": False, "reason": "job_not_pending_review"}
            job.rewrite_count += 1
            self.moderation_repository.update_status(job, status="generating")
            review = self._require_review(job.review_id)
            review.status = "generating"
            self.ai_task_repository.requeue(job.id)
            jobs_to_enqueue.append(job.id)
            self.logger.info("reply_rewritten", extra={"job_id": job.id, "rewrite_count": job.rewrite_count})
            return {"ok": True, "action": action, "jobId": str(job.id)}

        if action == "ignore":
            job = self._require_job(job_id)
            if not self._can_transition(job.status, expected_status="pending_review"):
                return {"ok": True, "action": action, "jobId": str(job.id), "handled": False, "reason": "job_not_pending_review"}
            self.moderation_repository.update_status(job, status="ignored")
            review = self._require_review(job.review_id)
            review.status = "ignored"
            self._send_resolution_message(
                title="Отзыв пропущен",
                body_lines=["Текущий отзыв помечен как пропущенный."],
                follow_up_job_id=job.id,
            )
            self.logger.info("reply_ignored", extra={"job_id": job.id})
            return {"ok": True, "action": action, "jobId": str(job.id)}

        if action == "edit":
            job = self._require_job(job_id)
            self._send_edit_instructions(job.id)
            return {"ok": True, "action": action, "jobId": str(job.id), "mode": "edit_requested"}

        if action == "continue":
            job = self._require_job(job_id)
            review = self._require_review(job.review_id)
            result = self.dispatch_next_pending_for_account(review.account_id)
            if not result.get("handled"):
                self._send_plain_message("Очередь на модерацию пока пуста.")
            return {"ok": True, "action": action, "handled": bool(result.get("handled"))}

        return {"ok": True, "action": action, "handled": False}

    def _handle_message(
        self,
        message: dict[str, Any],
        *,
        update: dict[str, Any],
        update_id: str | None,
    ) -> dict[str, Any]:
        text = str(message.get("text", "")).strip()
        if not text.lower().startswith("edit:"):
            self.telegram_event_repository.add_event(
                action="message_ignored",
                payload=update,
                telegram_update_id=update_id,
            )
            return {"ok": True, "handled": False}

        job_id, reply_text = self._parse_edit_command(text)
        actor = self._extract_actor(message.get("from"))
        self.telegram_event_repository.add_event(
            action="edit",
            payload=update,
            job_id=job_id,
            telegram_update_id=update_id,
        )

        job = self._require_job(job_id)
        if not self._can_transition(job.status, expected_status="pending_review"):
            return {"ok": True, "action": "edit", "jobId": str(job.id), "handled": False, "reason": "job_not_pending_review"}
        self.moderation_repository.update_approved_reply(
            job,
            reply=reply_text,
            approved_by=actor,
            status="approved",
        )
        review = self._require_review(job.review_id)
        review.status = "approved"
        self._send_resolution_message(
            title="Ответ сохранён после ручной правки",
            body_lines=[
                "Исправленный текст принят и готов к публикации.",
                reply_text,
            ],
            follow_up_job_id=job.id,
        )
        self.logger.info("reply_approved", extra={"job_id": job.id, "approved_by": actor, "mode": "edit"})
        return {"ok": True, "action": "edit", "jobId": str(job.id)}

    def _format_moderation_message(self, *, job_id: UUID, review: Any, reply: str) -> str:
        author = self._clean_text(review.author) or "Не указано"
        review_date = self._clean_text(review.review_date) or "Не указано"
        address = self._clean_text(review.address) or "Не указано"
        account_id = self._clean_text(review.account_id) or "Не указано"
        review_text = self._truncate(self._clean_text(review.review_text), limit=2200)
        reply_text = self._truncate(self._clean_text(reply), limit=1400)
        page_url = self._clean_text(getattr(review, "page_url", None))
        status = self._status_label(review.status)

        lines = [
            self.CARD_SEPARATOR,
            "📝 Отзыв на модерацию",
            self.CARD_SEPARATOR,
            "",
            f"🆔 Заявка: {job_id}",
            f"🏢 Аккаунт: {account_id}",
            f"📌 Статус: {status}",
            f"⭐ Оценка: {review.rating}/5",
            f"👤 Автор: {author}",
            f"🗓 Дата: {review_date}",
            f"📍 Адрес: {address}",
            "",
            "💬 Текст отзыва:",
            review_text,
        ]
        if page_url:
            lines.extend(["", f"🔗 Ссылка: {page_url}"])
        lines.extend(
            [
                "",
                self.CARD_SEPARATOR,
                "🤖 Черновик ответа",
                self.CARD_SEPARATOR,
                "",
                reply_text or "Черновик ответа пока пуст.",
                "",
                "Действия: Согласовать, Переписать, Пропустить.",
                f"Ручная правка: нажмите Редактировать или отправьте edit:{job_id} Ваш исправленный ответ",
            ]
        )
        return "\n".join(lines)

    def _build_inline_keyboard(self, job_id: UUID) -> dict[str, Any]:
        return {
            "inline_keyboard": [
                [
                    {"text": "Согласовать", "callback_data": f"mod:approve:{job_id}"},
                    {"text": "Переписать", "callback_data": f"mod:rewrite:{job_id}"},
                    {"text": "Пропустить", "callback_data": f"mod:ignore:{job_id}"},
                ],
                [
                    {"text": "Редактировать", "callback_data": f"mod:edit:{job_id}"},
                ],
            ]
        }

    def _telegram_api(self, method: str, payload: dict[str, Any]) -> dict[str, Any]:
        body = json.dumps(payload).encode("utf-8")
        endpoint = (
            f"{self.settings.telegram_api_base.rstrip('/')}/bot"
            f"{self.settings.telegram_bot_token}/{method}"
        )
        req = request.Request(
            url=endpoint,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        def do_request():
            with request.urlopen(req, timeout=self.settings.telegram_timeout_seconds) as response:
                return json.loads(response.read().decode("utf-8"))

        return call_with_retry(
            do_request,
            attempts=self.settings.external_request_max_retries + 1,
            backoff_seconds=self.settings.external_request_backoff_seconds,
            retry_on=(HTTPError, URLError, TimeoutError),
            logger=self.logger,
            operation_name=f"telegram_{method}",
        )

    def _parse_callback_data(self, data: str) -> tuple[str, UUID | None]:
        parts = [part for part in data.split(":") if part]
        if len(parts) == 3 and parts[0] == "mod":
            return parts[1], UUID(parts[2])
        if len(parts) == 2:
            return parts[0], UUID(parts[1])
        if parts:
            return parts[0], None
        return "unknown", None

    def _parse_edit_command(self, text: str) -> tuple[UUID, str]:
        _, _, remainder = text.partition(":")
        raw_job_id, separator, reply_text = remainder.strip().partition(" ")
        if separator == "":
            raw_job_id, separator, reply_text = remainder.strip().partition("\n")
        if separator == "" or not reply_text.strip():
            raise ValueError("Edit command must include a job id and replacement reply text")
        return UUID(raw_job_id.strip()), reply_text.strip()

    def _extract_update_id(self, update: dict[str, Any]) -> str | None:
        value = update.get("update_id")
        if value is None:
            return None
        return str(value)

    def _extract_actor(self, actor_payload: Any) -> str | None:
        if not isinstance(actor_payload, dict):
            return None
        username = actor_payload.get("username")
        if username:
            return str(username)
        actor_id = actor_payload.get("id")
        if actor_id is not None:
            return str(actor_id)
        return None

    def _send_edit_instructions(self, job_id: UUID) -> None:
        if not self.settings.telegram_bot_token or not self.settings.telegram_chat_id:
            return
        payload = {
            "chat_id": self.settings.telegram_chat_id,
            "text": "\n".join(
                [
                    self.CARD_SEPARATOR,
                    "✏️ Редактирование ответа",
                    self.CARD_SEPARATOR,
                    "",
                    f"🆔 Заявка: {job_id}",
                    "",
                    "Чтобы сохранить финальный вариант, отправьте сообщением:",
                    f"edit:{job_id} Ваш исправленный ответ",
                ]
            ),
        }
        try:
            self._telegram_api("sendMessage", payload)
            self.telegram_event_repository.add_event(
                action="edit_requested",
                payload=payload,
                job_id=job_id,
            )
        except Exception:
            self.logger.exception("telegram_edit_instruction_failed", extra={"job_id": job_id})

    def _can_transition(self, current_status: str | None, *, expected_status: str) -> bool:
        return current_status == expected_status

    def _require_job(self, job_id: UUID | None):
        if job_id is None:
            raise ValueError("Telegram action does not include a moderation job id")
        job = self.moderation_repository.get(job_id)
        if job is None:
            raise ValueError(f"Moderation job {job_id} not found")
        return job

    def _require_review(self, review_id: UUID):
        review = self.review_repository.get(review_id)
        if review is None:
            raise ValueError(f"Review {review_id} not found")
        return review

    def _send_resolution_message(self, *, title: str, body_lines: list[str], follow_up_job_id: UUID) -> None:
        lines = [
            self.CARD_SEPARATOR,
            title,
            self.CARD_SEPARATOR,
            "",
            *[line for line in body_lines if line],
        ]
        self._send_plain_message("\n".join(lines), reply_markup=self._build_continue_keyboard(follow_up_job_id))

    def _build_continue_keyboard(self, job_id: UUID) -> dict[str, Any]:
        return {
            "inline_keyboard": [
                [
                    {"text": "Продолжить", "callback_data": f"mod:continue:{job_id}"},
                ]
            ]
        }

    def _send_plain_message(self, text: str, reply_markup: dict[str, Any] | None = None) -> None:
        if not self.settings.telegram_bot_token or not self.settings.telegram_chat_id:
            return
        payload: dict[str, Any] = {
            "chat_id": self.settings.telegram_chat_id,
            "text": text,
        }
        if reply_markup is not None:
            payload["reply_markup"] = reply_markup
        try:
            self._telegram_api("sendMessage", payload)
        except Exception:
            self.logger.exception("telegram_followup_send_failed")

    def _clean_text(self, value: Any) -> str:
        return " ".join(str(value or "").split()).strip()

    def _truncate(self, value: str, *, limit: int) -> str:
        if len(value) <= limit:
            return value
        return f"{value[: limit - 1].rstrip()}…"

    def _status_label(self, status: str | None) -> str:
        mapping = {
            "new": "Новый",
            "generating": "Генерируется",
            "pending_review": "Ждёт модерации",
            "approved": "Согласован",
            "published": "Опубликован",
            "failed": "Ошибка",
            "ignored": "Пропущен",
        }
        return mapping.get(str(status or "").strip(), str(status or "Не указано"))
