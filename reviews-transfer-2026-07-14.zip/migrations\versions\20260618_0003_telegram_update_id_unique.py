"""add telegram update id uniqueness"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


revision = "20260618_0003"
down_revision = "20260618_0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_index(
        "ix_telegram_events_telegram_update_id",
        "telegram_events",
        ["telegram_update_id"],
        unique=True,
    )


def downgrade() -> None:
    op.drop_index("ix_telegram_events_telegram_update_id", table_name="telegram_events")
