from urllib.error import URLError

import pytest

from apps.backend.app.utils.retry import call_with_retry


def test_call_with_retry_retries_and_succeeds() -> None:
    attempts = {"count": 0}

    def flaky_operation() -> str:
        attempts["count"] += 1
        if attempts["count"] < 3:
            raise URLError("temporary failure")
        return "ok"

    result = call_with_retry(
        flaky_operation,
        attempts=3,
        backoff_seconds=0,
        retry_on=(URLError,),
    )

    assert result == "ok"
    assert attempts["count"] == 3


def test_call_with_retry_raises_when_attempts_exhausted() -> None:
    def always_fail() -> None:
        raise URLError("still failing")

    with pytest.raises(URLError):
        call_with_retry(
            always_fail,
            attempts=2,
            backoff_seconds=0,
            retry_on=(URLError,),
        )
