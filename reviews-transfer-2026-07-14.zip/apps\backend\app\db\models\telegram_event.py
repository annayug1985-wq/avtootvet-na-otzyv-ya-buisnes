from __future__ import annotations

from datetime import datetime, timezone
import uuid

from sqlalchemy import DateTime, ForeignKey, JSON, String
from sqlalchemy.orm import Mapped, mapped_column

from apps.backend.app.db.base import Base


class TelegramEvent(Base):
    __tablename__ = "telegram_events"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    telegram_update_id: Mapped[str | None] = mapped_column(String(255), nullable=True, unique=True, index=True)
    job_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("moderation_jobs.id", ondelete="SET NULL"), nullable=True)
    action: Mapped[str] = mapped_column(String(64))
    payload: Mapped[dict] = mapped_column(JSON())
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
