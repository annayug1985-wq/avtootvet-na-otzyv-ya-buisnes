from __future__ import annotations

from datetime import datetime, timezone
import uuid

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from apps.backend.app.db.base import Base


class ModerationJob(Base):
    __tablename__ = "moderation_jobs"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    review_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("reviews.id", ondelete="CASCADE"))
    status: Mapped[str] = mapped_column(String(32), index=True)
    generated_reply: Mapped[str | None] = mapped_column(Text(), nullable=True)
    approved_reply: Mapped[str | None] = mapped_column(Text(), nullable=True)
    rewrite_count: Mapped[int] = mapped_column(Integer(), default=0)
    approved_by: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    review: Mapped["Review"] = relationship(back_populates="moderation_jobs")
