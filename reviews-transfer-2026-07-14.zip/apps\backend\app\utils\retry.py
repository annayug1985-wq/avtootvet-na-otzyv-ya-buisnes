from __future__ import annotations

import time
from collections.abc import Callable
from typing import ParamSpec, TypeVar

P = ParamSpec("P")
R = TypeVar("R")


def call_with_retry(
    operation: Callable[P, R],
    *args: P.args,
    attempts: int,
    backoff_seconds: float,
    retry_on: tuple[type[BaseException], ...],
    logger=None,
    operation_name: str = "external_call",
    context: dict | None = None,
    **kwargs: P.kwargs,
) -> R:
    if attempts < 1:
        raise ValueError("attempts must be at least 1")

    retry_context = context or {}
    for attempt in range(1, attempts + 1):
        try:
            return operation(*args, **kwargs)
        except retry_on as exc:
            if attempt >= attempts:
                raise
            if logger is not None:
                logger.warning(
                    "external_call_retry",
                    extra={
                        "operation": operation_name,
                        "attempt": attempt,
                        "max_attempts": attempts,
                        "error": str(exc),
                        **retry_context,
                    },
                )
            time.sleep(backoff_seconds * attempt)

    raise RuntimeError("Retry loop exited unexpectedly")
