from sqlalchemy.orm import Session

from fastapi import APIRouter, Depends

from apps.backend.app.api.dependencies import get_db
from apps.backend.app.services.telegram_service import TelegramService

router = APIRouter(prefix="/api/telegram", tags=["telegram"])


@router.post("/webhook")
def telegram_webhook(payload: dict, db: Session = Depends(get_db)) -> dict:
    service = TelegramService(db)
    try:
        service.handle_update(payload)
    except Exception:
        db.rollback()
    return {"ok": True}
