from __future__ import annotations

from pathlib import Path


class PromptService:
    def __init__(self, prompt_path: Path | None = None) -> None:
        self.prompt_path = prompt_path or Path(__file__).resolve().parents[1] / "prompts" / "review_reply.prompt.txt"

    def render_review_reply_prompt(
        self,
        *,
        review_text: str,
        rating: int,
        examples: list[dict[str, str | int | None]],
        previous_reply: str | None,
    ) -> str:
        template = self.prompt_path.read_text(encoding="utf-8")
        examples_block = "\n\n".join(
            (
                f"Example {index} (rating={example['rating']}):\n"
                f"Review: {example['review_text']}\n"
                f"Reply: {example['answer_text']}"
            )
            for index, example in enumerate(examples, start=1)
        )
        if not examples_block:
            examples_block = "No approved examples yet."

        previous_reply_block = previous_reply or "No previous draft."
        return template.format(
            rating=rating,
            review_text=review_text,
            examples_block=examples_block,
            previous_reply_block=previous_reply_block,
        )
