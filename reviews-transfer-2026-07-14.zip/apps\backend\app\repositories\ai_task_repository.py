from __future__ import annotations

from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from apps.backend.app.db.models.ai_task import AiTask


class AiTaskRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get_by_job_id(self, job_id: UUID) -> AiTask | None:
        return self.db.scalar(select(AiTask).where(AiTask.job_id == job_id))

    def enqueue(self, job_id: UUID) -> AiTask:
        existing = self.get_by_job_id(job_id)
        if existing is not None:
            return existing

        task = AiTask(job_id=job_id, status="pending")
        self.db.add(task)
        self.db.flush()
        return task

    def get_next_pending(self) -> AiTask | None:
        return self.db.scalar(select(AiTask).where(AiTask.status == "pending").order_by(AiTask.created_at.asc()))

    def requeue(self, job_id: UUID) -> AiTask:
        task = self.get_by_job_id(job_id)
        if task is None:
            return self.enqueue(job_id)

        task.status = "pending"
        task.last_error = None
        self.db.add(task)
        self.db.flush()
        return task
