from __future__ import annotations

from abc import ABC, abstractmethod


class AiProviderError(Exception):
    retryable = False


class AiProviderTransientError(AiProviderError):
    retryable = True


class AiProviderAuthError(AiProviderError):
    pass


class AiProviderRateLimitError(AiProviderError):
    retryable = True


class AiProviderResponseError(AiProviderError):
    pass


class AiProviderQualityError(AiProviderError):
    pass


class BaseAiProvider(ABC):
    @abstractmethod
    def generate_reply(
        self,
        *,
        review_text: str,
        rating: int,
        prompt: str,
        examples: list[dict[str, str | int | None]],
        previous_reply: str | None = None,
    ) -> str:
        raise NotImplementedError
