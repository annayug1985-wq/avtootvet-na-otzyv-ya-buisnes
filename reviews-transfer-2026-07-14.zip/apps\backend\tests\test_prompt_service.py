from pathlib import Path
from uuid import uuid4

from apps.backend.app.services.prompt_service import PromptService


def test_prompt_service_includes_previous_reply_and_examples() -> None:
    prompt_file = Path.cwd() / f"prompt-test-{uuid4()}.txt"
    try:
        prompt_file.write_text(
            "Rating: {rating}\nReview: {review_text}\nExamples:\n{examples_block}\nPrevious:\n{previous_reply_block}",
            encoding="utf-8",
        )
        service = PromptService(prompt_path=prompt_file)

        result = service.render_review_reply_prompt(
            review_text="Все отлично",
            rating=5,
            examples=[{"review_text": "Пример", "answer_text": "Спасибо!", "rating": 5}],
            previous_reply="Черновик",
        )

        assert "Все отлично" in result
        assert "Пример" in result
        assert "Спасибо!" in result
        assert "Черновик" in result
    finally:
        if prompt_file.exists():
            prompt_file.unlink()
