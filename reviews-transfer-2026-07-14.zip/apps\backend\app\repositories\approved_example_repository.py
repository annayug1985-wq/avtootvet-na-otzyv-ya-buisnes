from __future__ import annotations

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from apps.backend.app.db.models.approved_example import ApprovedExample


class ApprovedExampleRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def list_recent(self, *, limit: int, rating: int | None = None) -> list[ApprovedExample]:
        stmt = select(ApprovedExample).order_by(ApprovedExample.created_at.desc()).limit(limit)
        if rating is not None:
            stmt = stmt.where(or_(ApprovedExample.rating == rating, ApprovedExample.rating.is_(None)))
        return list(self.db.scalars(stmt))

    def add(self, *, review_text: str, answer_text: str, rating: int | None = None) -> ApprovedExample:
        example = ApprovedExample(
            review_text=review_text,
            answer_text=answer_text,
            rating=rating,
        )
        self.db.add(example)
        self.db.flush()
        return example
