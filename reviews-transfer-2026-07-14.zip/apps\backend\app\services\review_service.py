from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from apps.backend.app.db.models.moderation_job import ModerationJob
from apps.backend.app.db.models.review import Review
from apps.backend.app.repositories.approved_example_repository import ApprovedExampleRepository
from apps.backend.app.repositories.ai_task_repository import AiTaskRepository
from apps.backend.app.repositories.moderation_repository import ModerationRepository
from apps.backend.app.repositories.review_repository import ReviewRepository
from apps.backend.app.repositories.telegram_event_repository import TelegramEventRepository
from apps.backend.app.schemas.review import ReviewCreateRequest
from apps.backend.app.services.dedupe_service import build_review_key
from apps.backend.app.services.queue_service import QueueService
from apps.backend.app.utils import get_logger


class ReviewService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.logger = get_logger("reviews.review_service")
        self.review_repository = ReviewRepository(db)
        self.moderation_repository = ModerationRepository(db)
        self.ai_task_repository = AiTaskRepository(db)
        self.approved_example_repository = ApprovedExampleRepository(db)
        self.telegram_event_repository = TelegramEventRepository(db)
        self.queue_service = QueueService()

    def create_or_get(self, payload: ReviewCreateRequest) -> dict:
        self.logger.info(
            "review_received",
            extra={"account_id": payload.accountId, "rating": payload.rating, "source": payload.source},
        )
        review_key = build_review_key(
            account_id=payload.accountId,
            rating=payload.rating,
            author=payload.author,
            review_date=payload.date,
            address=payload.address,
            review_text=payload.reviewText,
        )
        existing_review = self.review_repository.get_by_review_key(review_key)
        if existing_review is not None:
            existing_job = self.moderation_repository.get_by_review_id(existing_review.id)
            if existing_job is None:
                raise LookupError(f"Moderation job for review {existing_review.id} not found")
            if existing_job.status == "ignored":
                cleared_events = self.telegram_event_repository.delete_actions_for_job(
                    job_id=existing_job.id,
                    actions=["sent_for_moderation", "sent_channel_copy", "edit_requested"],
                )
                self.moderation_repository.update_status(existing_job, status="generating")
                existing_review.status = "generating"
                self.ai_task_repository.requeue(existing_job.id)
                self.db.commit()
                self.db.refresh(existing_review)
                self.db.refresh(existing_job)
                self.queue_service.enqueue_ai_job(existing_job.id)
                self.logger.info(
                    "ignored_review_requeued",
                    extra={
                        "review_id": existing_review.id,
                        "job_id": existing_job.id,
                        "account_id": payload.accountId,
                        "cleared_telegram_events": cleared_events,
                    },
                )
                return {
                    "ok": True,
                    "reviewId": existing_review.id,
                    "jobId": existing_job.id,
                    "status": existing_job.status,
                    "duplicate": False,
                }
            self.logger.info(
                "duplicate_detected",
                extra={"review_id": existing_review.id, "job_id": existing_job.id, "account_id": payload.accountId},
            )
            return {
                "ok": True,
                "reviewId": existing_review.id,
                "jobId": existing_job.id,
                "status": existing_job.status,
                "duplicate": True,
            }

        review = Review(
            review_key=review_key,
            source=payload.source,
            account_id=payload.accountId,
            author=payload.author,
            rating=payload.rating,
            review_text=payload.reviewText,
            address=payload.address,
            review_date=payload.date,
            page_url=payload.pageUrl,
            status="generating",
        )
        job = ModerationJob(status="generating")
        review.moderation_jobs.append(job)
        self.review_repository.add(review)
        self.ai_task_repository.enqueue(job.id)
        self.db.commit()
        self.db.refresh(review)
        self.db.refresh(job)
        self.queue_service.enqueue_ai_job(job.id)
        self.logger.info(
            "job_created",
            extra={"review_id": review.id, "job_id": job.id, "account_id": review.account_id},
        )
        return {
            "ok": True,
            "reviewId": review.id,
            "jobId": job.id,
            "status": job.status,
            "duplicate": False,
        }

    def get_job(self, job_id: UUID) -> ModerationJob | None:
        return self.moderation_repository.get(job_id)

    def get_client_reply(self, job: ModerationJob) -> str | None:
        if job.status not in {"approved", "published"}:
            return None
        return job.approved_reply

    def get_next_approved_for_account(self, account_id: str) -> dict:
        row = self.db.execute(
            select(Review, ModerationJob)
            .join(ModerationJob, ModerationJob.review_id == Review.id)
            .where(
                Review.account_id == account_id,
                ModerationJob.status == "approved",
                ModerationJob.approved_reply.is_not(None),
            )
            .order_by(ModerationJob.updated_at.asc())
            .limit(1)
        ).first()

        if row is None:
            return {"ok": True, "review": None}

        review, job = row
        return {
            "ok": True,
            "review": {
                "id": review.id,
                "reviewId": review.id,
                "reviewKey": review.review_key,
                "stars": review.rating,
                "author": review.author,
                "date": review.review_date,
                "address": review.address,
                "reviewText": review.review_text,
                "reply": job.approved_reply,
            },
        }

    def retry_job(self, job_id: UUID) -> dict:
        job = self.moderation_repository.get(job_id)
        if job is None:
            raise LookupError("Job not found")
        if job.status != "failed":
            raise PermissionError("Only failed jobs can be retried")

        review = self.review_repository.get(job.review_id)
        if review is None:
            raise LookupError("Review not found")

        self.moderation_repository.update_status(job, status="generating")
        review.status = "generating"
        self.ai_task_repository.requeue(job.id)
        self.db.commit()
        self.db.refresh(job)
        self.queue_service.enqueue_ai_job(job.id)
        self.logger.info(
            "job_requeued",
            extra={"review_id": review.id, "job_id": job.id, "account_id": review.account_id},
        )
        return {
            "ok": True,
            "jobId": job.id,
            "status": job.status,
            "reply": None,
        }

    def mark_review_published(self, review_id: UUID, *, published: bool) -> dict:
        if not published:
            raise ValueError("Only published=true is supported")

        review = self.review_repository.get(review_id)
        if review is None:
            raise LookupError("Review not found")

        job = self.moderation_repository.get_by_review_id(review.id)
        if job is None:
            raise LookupError("Moderation job not found")

        if job.status == "published":
            return {
                "ok": True,
                "reviewId": review.id,
                "jobId": job.id,
                "status": job.status,
            }

        if job.status != "approved" or not job.approved_reply:
            raise PermissionError("Review cannot be published before approval")

        self.moderation_repository.update_status(job, status="published")
        review.status = "published"
        self.approved_example_repository.add(
            review_text=review.review_text,
            answer_text=job.approved_reply,
            rating=review.rating,
        )
        self.db.commit()
        self.db.refresh(review)
        self.db.refresh(job)
        self.logger.info(
            "reply_published",
            extra={"review_id": review.id, "job_id": job.id, "account_id": review.account_id},
        )
        return {
            "ok": True,
            "reviewId": review.id,
            "jobId": job.id,
            "status": job.status,
        }
