from __future__ import annotations

import argparse

from redis import Redis
from rq import Worker

from apps.backend.app.config.settings import get_settings
from apps.backend.app.utils import configure_logging, get_logger

settings = get_settings()
configure_logging(settings.log_level)
logger = get_logger("reviews.rq_worker")


def run_worker(queue_names: list[str]) -> int:
    connection = Redis.from_url(settings.redis_url)
    logger.info("worker_started", extra={"queues": queue_names, "redis_url": settings.redis_url})
    worker = Worker(queue_names, connection=connection)
    worker.work(with_scheduler=False)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Run Redis-backed RQ workers.")
    parser.add_argument("queues", nargs="*", default=[settings.ai_queue_name, settings.telegram_queue_name])
    args = parser.parse_args()
    return run_worker(args.queues)


if __name__ == "__main__":
    raise SystemExit(main())
