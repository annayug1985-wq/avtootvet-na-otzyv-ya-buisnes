from apps.backend.app.config.settings import Settings
from apps.backend.app.providers.base import (
    AiProviderAuthError,
    AiProviderError,
    AiProviderQualityError,
    AiProviderRateLimitError,
    AiProviderResponseError,
    AiProviderTransientError,
    BaseAiProvider,
)
from apps.backend.app.providers.gigachat import GigaChatProvider
from apps.backend.app.providers.ollama import OllamaProvider
from apps.backend.app.providers.openai import OpenAIProvider
from apps.backend.app.providers.yandexgpt import YandexGptProvider


def build_ai_provider(settings: Settings) -> BaseAiProvider:
    provider_name = settings.ai_provider.lower()
    providers: dict[str, type[BaseAiProvider]] = {
        "ollama": OllamaProvider,
        "openai": OpenAIProvider,
        "yandexgpt": YandexGptProvider,
        "gigachat": GigaChatProvider,
    }
    provider_class = providers.get(provider_name)
    if provider_class is None:
        raise ValueError(f"Unsupported AI provider: {settings.ai_provider}")
    return provider_class(settings)

__all__ = [
    "AiProviderAuthError",
    "AiProviderError",
    "AiProviderQualityError",
    "AiProviderRateLimitError",
    "AiProviderResponseError",
    "AiProviderTransientError",
    "BaseAiProvider",
    "GigaChatProvider",
    "OllamaProvider",
    "OpenAIProvider",
    "YandexGptProvider",
    "build_ai_provider",
]
