from __future__ import annotations

import base64
import json
import uuid
from urllib import request
from urllib.error import HTTPError, URLError

from apps.backend.app.config.settings import Settings
from apps.backend.app.providers.base import (
    AiProviderAuthError,
    AiProviderRateLimitError,
    AiProviderResponseError,
    AiProviderTransientError,
    BaseAiProvider,
)
from apps.backend.app.utils import call_with_retry, get_logger


class GigaChatProvider(BaseAiProvider):
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.logger = get_logger("reviews.ai.gigachat")

    def generate_reply(
        self,
        *,
        review_text: str,
        rating: int,
        prompt: str,
        examples: list[dict[str, str | int | None]],
        previous_reply: str | None = None,
    ) -> str:
        token = self._get_access_token()
        payload = {
            "model": "GigaChat",
            "messages": [{"role": "user", "content": prompt}],
        }
        body = json.dumps(payload).encode("utf-8")
        req = request.Request(
            url=self.settings.gigachat_api_base,
            data=body,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        def do_request():
            try:
                with request.urlopen(req, timeout=self.settings.ollama_timeout_seconds) as response:
                    return json.loads(response.read().decode("utf-8"))
            except HTTPError as exc:
                if exc.code in {401, 403}:
                    raise AiProviderAuthError("GigaChat authentication failed") from exc
                if exc.code == 429:
                    raise AiProviderRateLimitError("GigaChat rate limit") from exc
                if exc.code >= 500:
                    raise AiProviderTransientError("GigaChat upstream error") from exc
                raise AiProviderResponseError(f"GigaChat request failed with {exc.code}") from exc
            except URLError as exc:
                raise AiProviderTransientError("GigaChat network error") from exc

        data = call_with_retry(
            do_request,
            attempts=self.settings.external_request_max_retries + 1,
            backoff_seconds=self.settings.external_request_backoff_seconds,
            retry_on=(AiProviderTransientError, AiProviderRateLimitError),
            logger=self.logger,
            operation_name="gigachat_generate",
        )
        reply = str(data.get("choices", [{}])[0].get("message", {}).get("content", "")).strip()
        if not reply:
            raise AiProviderResponseError("GigaChat returned an empty response")
        return reply

    def _get_access_token(self) -> str:
        if not self.settings.gigachat_client_id or not self.settings.gigachat_client_secret:
            raise AiProviderAuthError("GIGACHAT_CLIENT_ID or GIGACHAT_CLIENT_SECRET is not configured")

        credentials = f"{self.settings.gigachat_client_id}:{self.settings.gigachat_client_secret}"
        encoded = base64.b64encode(credentials.encode("utf-8")).decode("utf-8")
        body = f"scope={self.settings.gigachat_scope}".encode("utf-8")
        req = request.Request(
            url=self.settings.gigachat_auth_url,
            data=body,
            headers={
                "Authorization": f"Basic {encoded}",
                "Content-Type": "application/x-www-form-urlencoded",
                "RqUID": str(uuid.uuid4()),
            },
            method="POST",
        )

        def do_request():
            try:
                with request.urlopen(req, timeout=self.settings.ollama_timeout_seconds) as response:
                    return json.loads(response.read().decode("utf-8"))
            except HTTPError as exc:
                if exc.code in {401, 403}:
                    raise AiProviderAuthError("GigaChat token request failed") from exc
                if exc.code == 429:
                    raise AiProviderRateLimitError("GigaChat token rate limit") from exc
                if exc.code >= 500:
                    raise AiProviderTransientError("GigaChat token upstream error") from exc
                raise AiProviderResponseError(f"GigaChat token request failed with {exc.code}") from exc
            except URLError as exc:
                raise AiProviderTransientError("GigaChat token network error") from exc

        data = call_with_retry(
            do_request,
            attempts=self.settings.external_request_max_retries + 1,
            backoff_seconds=self.settings.external_request_backoff_seconds,
            retry_on=(AiProviderTransientError, AiProviderRateLimitError),
            logger=self.logger,
            operation_name="gigachat_auth",
        )
        token = str(data.get("access_token", "")).strip()
        if not token:
            raise AiProviderResponseError("GigaChat auth returned an empty token")
        return token
