from uuid import UUID

from pydantic import BaseModel


class JobStatusResponse(BaseModel):
    ok: bool
    jobId: UUID
    status: str
    reply: str | None = None
