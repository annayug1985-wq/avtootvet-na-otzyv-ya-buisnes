from __future__ import annotations

from uuid import UUID

from sqlalchemy import delete
from sqlalchemy import select
from sqlalchemy.orm import Session

from apps.backend.app.db.models.telegram_event import TelegramEvent


class TelegramEventRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get_by_update_id(self, update_id: str) -> TelegramEvent | None:
        return self.db.scalar(
            select(TelegramEvent).where(TelegramEvent.telegram_update_id == update_id)
        )

    def add_event(
        self,
        *,
        action: str,
        payload: dict,
        job_id: UUID | None = None,
        telegram_update_id: str | None = None,
    ) -> TelegramEvent:
        event = TelegramEvent(
            action=action,
            payload=payload,
            job_id=job_id,
            telegram_update_id=telegram_update_id,
        )
        self.db.add(event)
        self.db.flush()
        return event

    def has_action_for_job(self, *, job_id: UUID, action: str) -> bool:
        return self.db.scalar(
            select(TelegramEvent.id).where(
                TelegramEvent.job_id == job_id,
                TelegramEvent.action == action,
            ).limit(1)
        ) is not None

    def delete_actions_for_job(self, *, job_id: UUID, actions: list[str]) -> int:
        if not actions:
            return 0
        result = self.db.execute(
            delete(TelegramEvent).where(
                TelegramEvent.job_id == job_id,
                TelegramEvent.action.in_(actions),
            )
        )
        return int(result.rowcount or 0)
