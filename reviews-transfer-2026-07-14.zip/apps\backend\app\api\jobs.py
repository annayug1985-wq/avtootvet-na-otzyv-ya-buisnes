from uuid import UUID

from sqlalchemy.orm import Session

from fastapi import APIRouter, Depends, HTTPException, status

from apps.backend.app.api.dependencies import get_db
from apps.backend.app.schemas.job import JobStatusResponse
from apps.backend.app.services.review_service import ReviewService

router = APIRouter(prefix="/api/jobs", tags=["jobs"])


@router.get("/{job_id}", response_model=JobStatusResponse)
def get_job(job_id: UUID, db: Session = Depends(get_db)) -> JobStatusResponse:
    service = ReviewService(db)
    job = service.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
    return JobStatusResponse(
        ok=True,
        jobId=job.id,
        status=job.status,
        reply=service.get_client_reply(job),
    )


@router.post("/{job_id}/retry", response_model=JobStatusResponse)
def retry_job(job_id: UUID, db: Session = Depends(get_db)) -> JobStatusResponse:
    service = ReviewService(db)
    try:
        result = service.retry_job(job_id)
    except LookupError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    except PermissionError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    return JobStatusResponse(**result)
