# Настройка

## Локальный запуск на Python

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -e .[test]
alembic upgrade head
uvicorn apps.backend.app.main:app --reload
```

AI-воркер:

```bash
python -m apps.backend.app.workers.ai_worker --forever --limit 10
```

Redis/RQ-воркер:

```bash
python -m apps.backend.app.workers.rq_worker ai telegram
```

## Docker Compose

```bash
docker compose up --build
```

Сервисы:

- `postgres` хранит постоянное состояние
- `redis` используется как транспорт очередей
- `migrate` один раз применяет Alembic-миграции перед запуском приложения
- `backend` поднимает FastAPI HTTP API
- `worker` обрабатывает фоновые задачи через Redis/RQ

Порядок запуска:

- дождаться healthcheck для `postgres` и `redis`
- выполнить `migrate`
- запустить `backend`
- запустить `worker`

## Логирование

Логи пишутся в формате JSON lines и содержат:

- `request_id` для HTTP-запросов
- `job_id` и `review_id` для событий воркеров и модерации
- метаданные retry для исходящих вызовов в LLM и Telegram

## Замечания по Telegram webhook

- в продакшене нужен публичный HTTPS URL, ведущий на `/api/telegram/webhook`
- локальное тестирование webhook обычно требует туннель, например `ngrok`, или аналогичный сервис

## Регистрация реального Telegram webhook

1. Откройте локальный бэкенд наружу через публичный HTTPS URL.
2. Запишите этот URL в `.env` как `APP_BASE_URL=https://your-public-host`.
3. Перезапустите стек, чтобы бэкенд подхватил новый адрес.
4. Зарегистрируйте webhook:

```bash
python -m apps.backend.app.scripts.telegram_webhook set
```

5. Проверьте, что Telegram видит webhook:

```bash
python -m apps.backend.app.scripts.telegram_webhook info
```

Ожидаемый формат webhook URL:

```text
https://your-public-host/api/telegram/webhook
```
