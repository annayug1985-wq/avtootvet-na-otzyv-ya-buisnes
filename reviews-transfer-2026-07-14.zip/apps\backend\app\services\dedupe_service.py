import hashlib
import re

WHITESPACE_RE = re.compile(r"\s+")


def normalize_text(value: str) -> str:
    normalized = WHITESPACE_RE.sub(" ", value.strip().lower())
    return normalized


def build_review_key(
    *,
    account_id: str,
    rating: int,
    author: str | None,
    review_date: str | None,
    address: str | None,
    review_text: str,
) -> str:
    parts = [
        account_id.strip(),
        str(rating),
        (author or "").strip().lower(),
        (review_date or "").strip().lower(),
        (address or "").strip().lower(),
        normalize_text(review_text),
    ]
    payload = "|".join(parts)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()
