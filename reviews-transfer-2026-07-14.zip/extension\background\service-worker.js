const DEFAULT_SETTINGS = {
  backendBaseUrl: "http://localhost:8000",
  accountId: "account_1",
  autoModeEnabled: false
};

const STORAGE_KEYS = {
  settings: "settings",
  lastSync: "lastSync"
};

chrome.runtime.onInstalled.addListener(async () => {
  const { settings } = await chrome.storage.local.get(STORAGE_KEYS.settings);
  if (!settings) {
    await chrome.storage.local.set({ [STORAGE_KEYS.settings]: DEFAULT_SETTINGS });
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message)
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});

async function handleMessage(message) {
  switch (message?.type) {
    case "GET_SETTINGS":
      return { settings: await getSettings() };
    case "SAVE_SETTINGS":
      return { settings: await saveSettings(message.settings || {}) };
    case "CHECK_HEALTH":
      return { health: await checkHealth() };
    case "COLLECT_CURRENT_PAGE":
      return collectCurrentPage();
    case "REFRESH_STATUSES":
      return refreshStatuses();
    case "PUBLISH_APPROVED":
      return publishApproved();
    case "BACKEND_FETCH":
      return {
        data: await apiFetch(message.path, {
          method: message.method || "GET",
          body: message.body
        })
      };
    case "GET_LAST_SYNC":
      return { lastSync: await getLastSync() };
    default:
      throw new Error(`Unsupported message type: ${message?.type}`);
  }
}

async function getSettings() {
  const { settings } = await chrome.storage.local.get(STORAGE_KEYS.settings);
  return { ...DEFAULT_SETTINGS, ...(settings || {}) };
}

async function saveSettings(nextSettings) {
  const merged = { ...(await getSettings()), ...nextSettings };
  await chrome.storage.local.set({ [STORAGE_KEYS.settings]: merged });
  return merged;
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    throw new Error("No active tab available");
  }
  return tab;
}

async function sendToActiveTab(payload) {
  const tab = await getActiveTab();
  return chrome.tabs.sendMessage(tab.id, payload);
}

async function apiFetch(path, options = {}) {
  const settings = await getSettings();
  const response = await fetch(`${settings.backendBaseUrl.replace(/\/$/, "")}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Backend request failed: ${response.status} ${text}`);
  }

  return response.json();
}

async function checkHealth() {
  return apiFetch("/health", { method: "GET" });
}

async function collectCurrentPage() {
  const settings = await getSettings();
  const extraction = await sendToActiveTab({
    type: "EXTRACT_REVIEWS",
    accountId: settings.accountId
  });

  const jobs = [];
  for (const review of extraction.reviews) {
    const created = await apiFetch("/api/reviews", {
      method: "POST",
      body: JSON.stringify({
        accountId: review.accountId,
        rating: review.rating,
        author: review.author,
        date: review.date,
        address: review.address,
        reviewText: review.reviewText,
        pageUrl: review.pageUrl,
        source: "browser_extension"
      })
    });
    jobs.push({
      ...review,
      reviewId: created.reviewId,
      jobId: created.jobId,
      status: created.status,
      duplicate: created.duplicate
    });
  }

  const snapshot = {
    syncedAt: new Date().toISOString(),
    pageUrl: extraction.pageUrl,
    jobs,
    diagnostics: extraction.diagnostics || []
  };

  await chrome.storage.local.set({ [STORAGE_KEYS.lastSync]: snapshot });
  return { lastSync: snapshot };
}

async function getLastSync() {
  const { lastSync } = await chrome.storage.local.get(STORAGE_KEYS.lastSync);
  return lastSync || null;
}

async function refreshStatuses() {
  const lastSync = await getLastSync();
  if (!lastSync?.jobs?.length) {
    return { lastSync: null };
  }

  const jobs = [];
  for (const item of lastSync.jobs) {
    const current = await apiFetch(`/api/jobs/${item.jobId}`, { method: "GET" });
    jobs.push({
      ...item,
      status: current.status,
      reply: current.reply || null
    });
  }

  const snapshot = {
    ...lastSync,
    refreshedAt: new Date().toISOString(),
    jobs
  };

  await chrome.storage.local.set({ [STORAGE_KEYS.lastSync]: snapshot });
  return { lastSync: snapshot };
}

async function publishApproved() {
  const lastSync = await getLastSync();
  if (!lastSync?.jobs?.length) {
    throw new Error("No collected reviews to publish");
  }

  const approvedJobs = lastSync.jobs.filter((job) => job.status === "approved" && job.reply);
  if (!approvedJobs.length) {
    throw new Error("No approved replies are ready to publish");
  }

  const publication = await sendToActiveTab({
    type: "PUBLISH_APPROVED_REPLIES",
    jobs: approvedJobs
  });

  const publishedJobIds = new Set();
  for (const item of publication.published || []) {
    await apiFetch(`/api/reviews/${item.reviewId}/published`, {
      method: "POST",
      body: JSON.stringify({ published: true })
    });
    publishedJobIds.add(item.jobId);
  }

  const jobs = lastSync.jobs.map((job) => (
    publishedJobIds.has(job.jobId)
      ? { ...job, status: "published" }
      : job
  ));

  const snapshot = {
    ...lastSync,
    jobs,
    publishedAt: new Date().toISOString(),
    publication
  };

  await chrome.storage.local.set({ [STORAGE_KEYS.lastSync]: snapshot });
  return { lastSync: snapshot };
}
