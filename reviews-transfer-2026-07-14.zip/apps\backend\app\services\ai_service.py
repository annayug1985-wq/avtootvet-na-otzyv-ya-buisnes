from __future__ import annotations

import re

from sqlalchemy.orm import Session

from apps.backend.app.config.settings import get_settings
from apps.backend.app.db.models.moderation_job import ModerationJob
from apps.backend.app.db.models.review import Review
from apps.backend.app.providers import AiProviderQualityError, BaseAiProvider, build_ai_provider
from apps.backend.app.repositories.approved_example_repository import ApprovedExampleRepository
from apps.backend.app.services.prompt_service import PromptService
from apps.backend.app.utils import get_logger


class AiService:
    _BANNED_PHRASES = (
        "ваше мнение важно для нас",
        "будем рады видеть вас снова",
        "мы ценим каждого клиента",
    )
    _ROLE_PREFIXES = ("assistant:", "system:", "user:")
    _REQUIRED_SIGNATURE = 'С уважением, ГК "Альянс Тракс".'

    def __init__(self, db: Session, provider: BaseAiProvider | None = None) -> None:
        self.db = db
        self.settings = get_settings()
        self.provider = provider or build_ai_provider(self.settings)
        self.example_repository = ApprovedExampleRepository(db)
        self.prompt_service = PromptService()
        self.logger = get_logger("reviews.ai_service")

    def generate_reply_for(self, *, review: Review, job: ModerationJob) -> str:
        examples = self._load_examples(rating=review.rating)
        prompt = self.prompt_service.render_review_reply_prompt(
            review_text=review.review_text,
            rating=review.rating,
            examples=examples,
            previous_reply=job.generated_reply,
        )
        reply = self.provider.generate_reply(
            review_text=review.review_text,
            rating=review.rating,
            prompt=prompt,
            examples=examples,
            previous_reply=job.generated_reply,
        )
        return self._validate_reply(reply)

    def _load_examples(self, *, rating: int) -> list[dict[str, str | int | None]]:
        rows = self.example_repository.list_recent(limit=self.settings.ai_examples_limit, rating=rating)
        return [
            {
                "review_text": row.review_text,
                "answer_text": row.answer_text,
                "rating": row.rating,
            }
            for row in rows
        ]

    def _validate_reply(self, reply: str) -> str:
        cleaned = self._normalize_reply(reply)
        lowered = cleaned.lower()

        if not cleaned:
            raise AiProviderQualityError("AI provider returned an empty reply")
        if "{review_text}" in cleaned or "{rating}" in cleaned or "{examples_block}" in cleaned:
            raise AiProviderQualityError("AI reply still contains unresolved template placeholders")
        if len(cleaned) < 12:
            raise AiProviderQualityError("AI reply is too short to moderate safely")
        if lowered.startswith(self._ROLE_PREFIXES):
            raise AiProviderQualityError("AI reply leaked provider/system role text")
        if self._looks_like_markdown_or_list(cleaned):
            raise AiProviderQualityError("AI reply looks like markdown or a list instead of a final customer reply")
        if self._contains_cjk(cleaned):
            raise AiProviderQualityError("AI reply contains CJK characters")
        if self._has_too_little_cyrillic(cleaned):
            raise AiProviderQualityError("AI reply does not look like a Russian customer reply")
        if self._has_too_much_latin(cleaned):
            raise AiProviderQualityError("AI reply contains too much Latin text")
        if self._is_overly_template_like(lowered):
            raise AiProviderQualityError("AI reply is too template-like for safe moderation")
        return cleaned

    def _normalize_reply(self, reply: str) -> str:
        cleaned = " ".join(reply.split()).strip().strip("\"'`")
        if not cleaned:
            return cleaned

        cleaned = re.sub(r"([А-Яа-яЁё])(\d)", r"\1 \2", cleaned)
        cleaned = re.sub(r"(\d)([А-Яа-яЁё])", r"\1 \2", cleaned)

        signature_pattern = re.compile(r'с уважением,\s*гк\s*["«]?альянс тракс["»]?\.*$', re.IGNORECASE)
        if signature_pattern.search(cleaned):
            return signature_pattern.sub(self._REQUIRED_SIGNATURE, cleaned)

        cleaned = cleaned.rstrip(".! ")
        return f"{cleaned}. {self._REQUIRED_SIGNATURE}"

    def _looks_like_markdown_or_list(self, text: str) -> bool:
        stripped = text.lstrip()
        return stripped.startswith(("-", "*", "#", "1.", "2.", "3.", "```"))

    def _contains_cjk(self, text: str) -> bool:
        return bool(re.search(r"[\u3400-\u9FFF\u3040-\u30FF\uAC00-\uD7AF]", text))

    def _has_too_little_cyrillic(self, text: str) -> bool:
        cyrillic_count = len(re.findall(r"[А-Яа-яЁё]", text))
        return cyrillic_count < 8

    def _has_too_much_latin(self, text: str) -> bool:
        latin_count = len(re.findall(r"[A-Za-z]", text))
        cyrillic_count = len(re.findall(r"[А-Яа-яЁё]", text))
        return latin_count > 12 and latin_count > max(6, cyrillic_count // 3)

    def _is_overly_template_like(self, lowered: str) -> bool:
        banned_hits = sum(1 for phrase in self._BANNED_PHRASES if phrase in lowered)
        if banned_hits >= 2:
            return True
        if lowered in self._BANNED_PHRASES:
            return True
        if lowered.count("спасибо") > 2:
            return True
        return False
