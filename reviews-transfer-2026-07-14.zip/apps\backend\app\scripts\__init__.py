"""Operational helper scripts for the backend app."""
