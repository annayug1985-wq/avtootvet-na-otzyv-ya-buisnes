from __future__ import annotations

from uuid import UUID

from redis import Redis
from rq import Queue

from apps.backend.app.config.settings import Settings, get_settings
from apps.backend.app.utils import get_logger


class QueueService:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        self.logger = get_logger("reviews.queue")

    def enqueue_ai_job(self, job_id: UUID) -> bool:
        if not self._redis_enabled:
            self.logger.info("queue_enqueue_skipped", extra={"job_id": job_id, "queue": "ai", "transport": self.settings.queue_transport})
            return False

        queue = self._queue(self.settings.ai_queue_name)
        queue.enqueue("apps.backend.app.workers.ai_worker.run_ai_job", str(job_id), job_id=f"ai-{job_id}")
        self.logger.info("queue_job_enqueued", extra={"job_id": job_id, "queue": self.settings.ai_queue_name})
        return True

    def enqueue_telegram_job(self, job_id: UUID) -> bool:
        if not self._redis_enabled:
            self.logger.info(
                "queue_enqueue_skipped",
                extra={"job_id": job_id, "queue": "telegram", "transport": self.settings.queue_transport},
            )
            return False

        queue = self._queue(self.settings.telegram_queue_name)
        queue.enqueue("apps.backend.app.workers.telegram_worker.run_telegram_job", str(job_id), job_id=f"telegram-{job_id}")
        self.logger.info("queue_job_enqueued", extra={"job_id": job_id, "queue": self.settings.telegram_queue_name})
        return True

    @property
    def _redis_enabled(self) -> bool:
        return self.settings.queue_transport.lower() == "redis"

    def _queue(self, name: str) -> Queue:
        connection = Redis.from_url(self.settings.redis_url)
        return Queue(name, connection=connection)
