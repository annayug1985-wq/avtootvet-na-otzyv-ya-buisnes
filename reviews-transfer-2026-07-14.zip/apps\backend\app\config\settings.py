from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_env: str = "development"
    port: int = 8000
    app_base_url: str = "http://localhost:8000"
    database_url: str = "sqlite:///./reviews.db"
    redis_url: str = "redis://localhost:6379/0"
    queue_transport: str = "database"
    ai_queue_name: str = "ai"
    telegram_queue_name: str = "telegram"
    log_level: str = "INFO"
    ai_provider: str = "ollama"
    ai_examples_limit: int = 3
    ollama_url: str = "http://localhost:11434"
    ollama_model: str = "qwen2.5:7b"
    ollama_timeout_seconds: float = 30.0
    openai_api_key: str | None = None
    openai_api_base: str = "https://api.openai.com/v1"
    openai_model: str = "gpt-4.1-mini"
    yandexgpt_api_key: str | None = None
    yandexgpt_folder_id: str | None = None
    yandexgpt_api_base: str = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion"
    gigachat_client_id: str | None = None
    gigachat_client_secret: str | None = None
    gigachat_scope: str = "GIGACHAT_API_PERS"
    gigachat_auth_url: str = "https://ngw.devices.sberbank.ru:9443/api/v2/oauth"
    gigachat_api_base: str = "https://gigachat.devices.sberbank.ru/api/v1/chat/completions"
    telegram_timeout_seconds: float = 10.0
    external_request_max_retries: int = 2
    external_request_backoff_seconds: float = 1.0
    worker_poll_interval_seconds: float = 2.0
    telegram_bot_token: str | None = None
    telegram_chat_id: str | None = None
    telegram_channel_id: str | None = None
    telegram_api_base: str = "https://api.telegram.org"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )


@lru_cache
def get_settings() -> Settings:
    return Settings()
