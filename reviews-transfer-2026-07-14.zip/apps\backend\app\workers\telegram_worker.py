from __future__ import annotations

from uuid import UUID

from sqlalchemy.orm import Session

from apps.backend.app.db.session import SessionLocal
from apps.backend.app.services.telegram_service import TelegramService
from apps.backend.app.utils import configure_logging, get_logger
from apps.backend.app.config.settings import get_settings

settings = get_settings()
configure_logging(settings.log_level)
logger = get_logger("reviews.telegram_worker")


def process_telegram_job(job_id: UUID, *, db: Session) -> bool:
    logger.info("telegram_delivery_started", extra={"job_id": job_id})
    sent = TelegramService(db).send_for_moderation(job_id=job_id)
    logger.info("telegram_delivery_completed", extra={"job_id": job_id, "sent": sent})
    return sent


def run_telegram_job(job_id: str) -> None:
    db = SessionLocal()
    try:
        process_telegram_job(UUID(job_id), db=db)
    finally:
        db.close()
