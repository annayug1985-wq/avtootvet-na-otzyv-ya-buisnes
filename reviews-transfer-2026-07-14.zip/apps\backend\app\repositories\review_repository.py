from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from apps.backend.app.db.models.review import Review


class ReviewRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get_by_review_key(self, review_key: str) -> Review | None:
        return self.db.scalar(select(Review).where(Review.review_key == review_key))

    def get(self, review_id: UUID) -> Review | None:
        return self.db.get(Review, review_id)

    def add(self, review: Review) -> Review:
        self.db.add(review)
        self.db.flush()
        return review
