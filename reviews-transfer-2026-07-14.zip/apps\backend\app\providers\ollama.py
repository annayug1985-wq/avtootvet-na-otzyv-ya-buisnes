from __future__ import annotations

import json
from urllib.error import HTTPError, URLError
from urllib import request

from apps.backend.app.config.settings import Settings
from apps.backend.app.providers.base import BaseAiProvider
from apps.backend.app.utils import call_with_retry, get_logger


class OllamaProvider(BaseAiProvider):
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.logger = get_logger("reviews.ai.ollama")

    def generate_reply(
        self,
        *,
        review_text: str,
        rating: int,
        prompt: str,
        examples: list[dict[str, str | int | None]],
        previous_reply: str | None = None,
    ) -> str:
        payload = {
            "model": self.settings.ollama_model,
            "prompt": prompt,
            "stream": False,
        }
        body = json.dumps(payload).encode("utf-8")
        req = request.Request(
            url=f"{self.settings.ollama_url.rstrip('/')}/api/generate",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        def do_request():
            with request.urlopen(req, timeout=self.settings.ollama_timeout_seconds) as response:
                return json.loads(response.read().decode("utf-8"))

        data = call_with_retry(
            do_request,
            attempts=self.settings.external_request_max_retries + 1,
            backoff_seconds=self.settings.external_request_backoff_seconds,
            retry_on=(HTTPError, URLError, TimeoutError),
            logger=self.logger,
            operation_name="ollama_generate",
            context={"model": self.settings.ollama_model},
        )
        reply = str(data.get("response", "")).strip()
        if not reply:
            raise ValueError("Ollama returned an empty response")
        return reply
