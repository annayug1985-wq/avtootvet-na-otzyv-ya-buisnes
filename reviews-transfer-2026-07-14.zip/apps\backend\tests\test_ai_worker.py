from __future__ import annotations

from uuid import UUID

from sqlalchemy import select

from apps.backend.app.db.models.ai_task import AiTask
from apps.backend.app.db.models.approved_example import ApprovedExample
from apps.backend.app.providers.base import BaseAiProvider
from apps.backend.app.repositories.moderation_repository import ModerationRepository
from apps.backend.app.workers.ai_worker import process_next_ai_task


class FakeProvider(BaseAiProvider):
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    def generate_reply(
        self,
        *,
        review_text: str,
        rating: int,
        prompt: str,
        examples: list[dict[str, str | int | None]],
        previous_reply: str | None = None,
    ) -> str:
        self.calls.append(
            {
                "review_text": review_text,
                "rating": rating,
                "prompt": prompt,
                "examples": examples,
                "previous_reply": previous_reply,
            }
        )
        return "Спасибо за отзыв!"


def test_ai_worker_processes_pending_job(client, db_session) -> None:
    db_session.add(
        ApprovedExample(
            review_text="Очень вкусно",
            answer_text="Спасибо, что отметили кухню.",
            rating=5,
        )
    )
    db_session.commit()

    response = client.post(
        "/api/reviews",
        json={
            "accountId": "account_1",
            "rating": 5,
            "author": "Иван",
            "date": "2026-06-18",
            "address": "Москва",
            "reviewText": "Все отлично",
            "pageUrl": "https://example.com/review/1",
        },
    )
    assert response.status_code == 201

    provider = FakeProvider()
    processed_job_id = process_next_ai_task(db=db_session, provider=provider)

    job_id = UUID(response.json()["jobId"])
    assert processed_job_id == job_id

    job = ModerationRepository(db_session).get(job_id)
    assert job is not None
    assert job.status == "pending_review"
    assert job.generated_reply == "Спасибо за отзыв!"

    task = db_session.scalar(select(AiTask).where(AiTask.job_id == job.id))
    assert task is not None
    assert task.status == "done"
    assert task.attempt_count == 1

    assert len(provider.calls) == 1
    assert provider.calls[0]["examples"] == [
        {
            "review_text": "Очень вкусно",
            "answer_text": "Спасибо, что отметили кухню.",
            "rating": 5,
        }
    ]
    assert "Все отлично" in str(provider.calls[0]["prompt"])
