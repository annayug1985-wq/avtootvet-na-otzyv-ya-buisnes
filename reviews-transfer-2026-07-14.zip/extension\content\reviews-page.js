(function () {
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    Promise.resolve()
      .then(async () => {
        if (message?.type === "EXTRACT_REVIEWS") {
          return extractReviews(message.accountId);
        }
        if (message?.type === "PUBLISH_APPROVED_REPLIES") {
          return publishApprovedReplies(message.jobs || []);
        }
        throw new Error(`Unsupported content message type: ${message?.type}`);
      })
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ error: error.message }));

    return true;
  });

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function normalizeText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function isBadPageText(text) {
    return (
      text.includes(".yandex-header") ||
      text.includes("© 2001") ||
      text.includes("НастройкиУведомления") ||
      text.includes("СправкаПродвижение") ||
      text.includes("Бизнес ID") ||
      text.includes("Добавить организацию")
    );
  }

  function hashText(text) {
    let hash = 0;
    const value = String(text || "");
    for (let index = 0; index < value.length; index += 1) {
      hash = ((hash << 5) - hash) + value.charCodeAt(index);
      hash |= 0;
    }
    return String(Math.abs(hash));
  }

  function parseStars(card) {
    const ratingEl = card.querySelector(".StarsRating");
    if (!ratingEl) {
      return 0;
    }

    const className = String(ratingEl.className || "");
    const match = className.match(/StarsRating_value_(\d+)/);
    if (!match) {
      return 0;
    }

    return Math.round(Number(match[1]) / 2);
  }

  function extractDate(card) {
    const text = normalizeText(card.innerText);
    const match = text.match(/\d{1,2}\s+[А-Яа-яЁё]+\s+20\d{2}/);
    return match ? match[0] : "";
  }

  function extractAddress(card) {
    const addressEl =
      card.querySelector(".CompanyInfoCard-CompanyAddress") ||
      card.querySelector("[class*='CompanyInfoCard-CompanyAddress']");

    return addressEl ? normalizeText(addressEl.innerText) : "";
  }

  function extractAuthor(card) {
    const text = normalizeText(card.innerText);
    const date = extractDate(card);

    if (date && text.includes(date)) {
      const beforeDate = text.split(date)[0].trim();
      const parts = beforeDate
        .split(/\s{2,}|\n/)
        .map(normalizeText)
        .filter(Boolean);
      const possible = parts[parts.length - 1];

      if (possible && possible.length <= 80 && !isBadPageText(possible)) {
        return possible;
      }
    }

    return "Имя не найдено";
  }

  function findReplyField(card) {
    return card.querySelector("textarea, div[contenteditable='true'], input[type='text'], [role='textbox']");
  }

  function setEditableValue(field, text) {
    if ("value" in field) {
      const prototype = Object.getPrototypeOf(field);
      const descriptor = Object.getOwnPropertyDescriptor(prototype, "value");
      if (descriptor?.set) {
        descriptor.set.call(field, text);
      } else {
        field.value = text;
      }
      field.dispatchEvent(new Event("input", { bubbles: true }));
      field.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }

    field.innerText = text;
    field.textContent = text;
    field.dispatchEvent(new InputEvent("input", {
      bubbles: true,
      cancelable: true,
      inputType: "insertText",
      data: text
    }));
    field.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function findSendButton(card) {
    const buttonCandidates = [
      ...Array.from(card.querySelectorAll("button")),
      ...Array.from(document.querySelectorAll("button"))
    ];

    return buttonCandidates.find((button) => {
      const text = normalizeText(button.innerText);
      const className = String(button.className || "");
      const isDisabled =
        button.disabled ||
        button.getAttribute("aria-disabled") === "true" ||
        className.includes("disabled");

      if (isDisabled) {
        return false;
      }

      return (
        className.includes("BusinessResponseDraft-SendButton") ||
        /отправить|опубликовать|сохранить/i.test(text)
      );
    }) || null;
  }

  function isAlreadyAnswered(card) {
    const text = normalizeText(card.innerText);

    if (
      text.includes("Ответ владельца") ||
      (text.includes("Ответ компании") && !findReplyField(card))
    ) {
      return true;
    }

    const field = findReplyField(card);
    if (!field) {
      return true;
    }

    const value = "value" in field ? field.value : field.innerText;
    return normalizeText(value).length > 0;
  }

  function extractReviewText(card) {
    const clone = card.cloneNode(true);

    clone.querySelectorAll([
      "style",
      "script",
      "svg",
      "button",
      "textarea",
      "input",
      "[contenteditable='true']",
      ".CompanyInfoCard-CompanyAddress",
      "[class*='CompanyInfoCard-CompanyAddress']",
      ".FastComments",
      "[class*='FastComments']",
      ".FastComments-Comment",
      "[class*='FastComments-Comment']",
      ".BusinessResponseDraft",
      "[class*='BusinessResponseDraft']"
    ].join(", ")).forEach((node) => node.remove());

    let text = normalizeText(clone.innerText);

    const date = extractDate(card);
    const author = extractAuthor(card);
    const address = extractAddress(card);

    text = text
      .replace(/Альянс Тракс/gi, "")
      .replace(address, "")
      .replace(author, "")
      .replace(date, "")
      .replace(/Ответ компании/gi, "")
      .replace(/Ответ владельца/gi, "")
      .replace(/Отзывы/gi, "")
      .replace(/Обновления/gi, "")
      .replace(/Признак верификации/gi, "")
      .replace(/Данные/gi, "")
      .replace(/читать далее/gi, "")
      .replace(/Отменить редактирование/gi, "")
      .replace(/Спасибо за приятный отклик/gi, "")
      .replace(/Спасибо за приятный отзыв/gi, "")
      .replace(/Спасибо за вашу оценку/gi, "")
      .replace(/Спасибо за ваш отклик/gi, "")
      .replace(/Спасибо за ваш отзыв/gi, "")
      .replace(/Спасибо, мы старались/gi, "")
      .replace(/Спасибо, что оценили/gi, "")
      .replace(/Благодарим за ваш отзыв/gi, "")
      .replace(/Благодарим за вашу оценку/gi, "")
      .replace(/Спасибо за такой отзыв/gi, "")
      .replace(/★/g, "")
      .replace(/([а-яё])(\d)/gi, "$1 $2")
      .replace(/(\d)([А-Яа-яЁё])/g, "$1 $2")
      .trim();

    if (isBadPageText(text)) {
      return "";
    }

    if (text.length > 1000) {
      text = text.slice(0, 1000);
    }

    return text;
  }

  function findReviewCards() {
    const ratingEls = Array.from(document.querySelectorAll(".StarsRating"));
    const cards = [];
    const seen = new Set();

    for (const ratingEl of ratingEls) {
      let node = ratingEl.parentElement;

      for (let depth = 0; depth < 12 && node; depth += 1) {
        const text = normalizeText(node.innerText);
        const hasDate = /\d{1,2}\s+[А-Яа-яЁё]+\s+20\d{2}/.test(text);
        const hasReplyField = Boolean(
          node.querySelector("textarea, div[contenteditable='true'], input[type='text']")
        );

        if (
          hasDate &&
          hasReplyField &&
          text.length > 40 &&
          text.length < 2500 &&
          !isBadPageText(text)
        ) {
          const key = text.slice(0, 300);
          if (!seen.has(key)) {
            seen.add(key);
            cards.push(node);
          }
          break;
        }

        node = node.parentElement;
      }
    }

    cards.sort((left, right) => left.getBoundingClientRect().top - right.getBoundingClientRect().top);
    return cards;
  }

  function getCardExternalKey(card, accountId) {
    const stars = parseStars(card);
    const author = extractAuthor(card);
    const date = extractDate(card);
    const reviewText = extractReviewText(card);
    const address = extractAddress(card);

    return hashText([accountId, stars, author, date, address, reviewText].join("|"));
  }

  function cardToReview(card, cardIndex, accountId) {
    const rating = parseStars(card);
    const author = extractAuthor(card);
    const date = extractDate(card);
    const address = extractAddress(card);
    const reviewText = extractReviewText(card);
    const externalKey = getCardExternalKey(card, accountId);

    return {
      localKey: externalKey,
      externalKey,
      accountId,
      rating,
      author: author || null,
      date: date || null,
      address: address || null,
      reviewText,
      pageUrl: window.location.href,
      cardIndex
    };
  }

  function extractReviews(accountId) {
    const cards = findReviewCards();
    const diagnostics = [];
    const reviews = cards
      .map((card, index) => {
        const review = cardToReview(card, index, accountId);
        diagnostics.push({
          stage: "card_scan",
          cardIndex: index,
          alreadyAnswered: isAlreadyAnswered(card),
          rating: review.rating,
          reviewPreview: review.reviewText.slice(0, 120)
        });
        return { card, review };
      })
      .filter(({ card, review }) => !isAlreadyAnswered(card) && review.rating >= 1 && review.rating <= 5 && review.reviewText)
      .map(({ review }) => review);

    return {
      pageUrl: window.location.href,
      reviews,
      diagnostics
    };
  }

  function findCardForApprovedReview(job) {
    const cards = findReviewCards();

    for (const card of cards) {
      if (isAlreadyAnswered(card)) {
        continue;
      }

      const review = cardToReview(card, 0, job.accountId || "account_1");
      if (review.externalKey === job.externalKey) {
        return card;
      }

      const sameText = normalizeText(review.reviewText).slice(0, 150) === normalizeText(job.reviewText).slice(0, 150);
      if (sameText && review.date === (job.date || null) && review.rating === job.rating) {
        return card;
      }
    }

    return null;
  }

  async function insertReplyAndSubmit(card, replyText) {
    const reply = normalizeText(replyText);
    if (reply.length < 5) {
      throw new Error("reply_too_short");
    }

    const field = findReplyField(card);
    if (!field) {
      throw new Error("reply_field_missing");
    }

    field.scrollIntoView({ behavior: "smooth", block: "center" });
    await sleep(700);
    field.click();
    field.focus();
    await sleep(500);

    setEditableValue(field, "");
    await sleep(300);
    setEditableValue(field, reply);
    field.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "End" }));
    field.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "End" }));

    await sleep(1200);

    const fallbackSendButton = findSendButton(card);
    const sendButton =
      card.querySelector(".BusinessResponseDraft-SendButton") ||
      document.querySelector(".BusinessResponseDraft-SendButton") ||
      Array.from(document.querySelectorAll("button")).find((button) =>
        String(button.className || "").includes("BusinessResponseDraft-SendButton")
      ) ||
      Array.from(document.querySelectorAll("button")).find((button) =>
        /отправить|опубликовать/i.test(normalizeText(button.innerText))
      );

    const resolvedSendButton = sendButton || fallbackSendButton;
    if (!resolvedSendButton) {
      throw new Error("publish_button_missing");
    }

    resolvedSendButton.scrollIntoView({ behavior: "smooth", block: "center" });
    await sleep(500);
    clickLikeHuman(resolvedSendButton);
    await sleep(1500);
  }

  async function publishApprovedReplies(jobs) {
    const published = [];
    const diagnostics = [];

    for (const job of jobs) {
      const card = findCardForApprovedReview(job);
      if (!card) {
        diagnostics.push({
          stage: "publish",
          jobId: job.jobId,
          errorKind: "card_not_found",
          reviewPreview: normalizeText(job.reviewText).slice(0, 120)
        });
        continue;
      }

      try {
        await insertReplyAndSubmit(card, job.reply);
        published.push({ reviewId: job.reviewId, jobId: job.jobId });
      } catch (error) {
        diagnostics.push({
          stage: "publish",
          jobId: job.jobId,
          errorKind: error.message
        });
      }
    }

    return { published, diagnostics };
  }

  const SETTINGS_KEY = "settings";
  const AUTO_DEFAULTS = {
    backendBaseUrl: "http://localhost:8000",
    accountId: "account_1",
    autoModeEnabled: false,
    scanIntervalMs: 15000,
    scrollPauseMs: 2500,
    maxReviewsPerSync: 20,
    minPublishGapMs: 5000,
    paginationEnabled: true,
    paginationWaitMs: 5000,
    paginationBottomThresholdPx: 160
  };

  let autoLoopRunning = false;
  let autoLoopStopRequested = false;
  let autoLastPublishAt = 0;

  function getStateStorageKeys(accountId) {
    return {
      synced: `reviews_bot_synced_ids_${accountId}`,
      published: `reviews_bot_published_ids_${accountId}`
    };
  }

  function loadSetFromStorage(key) {
    try {
      return new Set(JSON.parse(localStorage.getItem(key) || "[]"));
    } catch {
      return new Set();
    }
  }

  function saveSetToStorage(key, value) {
    localStorage.setItem(key, JSON.stringify(Array.from(value).slice(-2000)));
  }

  async function getAutoSettings() {
    const { settings } = await chrome.storage.local.get(SETTINGS_KEY);
    return { ...AUTO_DEFAULTS, ...(settings || {}) };
  }

  async function backendFetch(path, options = {}) {
    const response = await chrome.runtime.sendMessage({
      type: "BACKEND_FETCH",
      path,
      method: options.method || "GET",
      body: options.body
    });

    if (!response?.ok) {
      throw new Error(response?.error || "backend_request_failed");
    }

    return response.data;
  }

  async function syncVisibleReviewsAuto(settings, syncedSet) {
    const extraction = extractReviews(settings.accountId);
    const reviews = extraction.reviews
      .filter((review) => !syncedSet.has(review.externalKey))
      .slice(0, settings.maxReviewsPerSync);

    if (!reviews.length) {
      return 0;
    }

    for (const review of reviews) {
      await backendFetch("/api/reviews", {
        method: "POST",
        body: JSON.stringify({
          accountId: review.accountId,
          rating: review.rating,
          author: review.author,
          date: review.date,
          address: review.address,
          reviewText: review.reviewText,
          pageUrl: review.pageUrl,
          source: "browser_extension_auto"
        })
      });
      syncedSet.add(review.externalKey);
    }

    return reviews.length;
  }

  async function publishNextApprovedAuto(settings, publishedSet) {
    const now = Date.now();
    if (now - autoLastPublishAt < settings.minPublishGapMs) {
      return false;
    }

    const response = await backendFetch(`/api/reviews/next-approved?accountId=${encodeURIComponent(settings.accountId)}`, {
      method: "GET"
    });
    if (!response.review) {
      return false;
    }

    const approvedReview = response.review;
    if (publishedSet.has(String(approvedReview.id))) {
      return false;
    }

    const card = findCardForApprovedReview({
      accountId: settings.accountId,
      externalKey: approvedReview.reviewKey,
      reviewText: approvedReview.reviewText,
      date: approvedReview.date || null,
      rating: approvedReview.stars
    });
    if (!card) {
      return false;
    }

    await insertReplyAndSubmit(card, approvedReview.reply);
    await backendFetch(`/api/reviews/${approvedReview.reviewId}/published`, {
      method: "POST",
      body: JSON.stringify({ published: true })
    });
    publishedSet.add(String(approvedReview.id));
    autoLastPublishAt = Date.now();
    return true;
  }

  function getScrollElement() {
    return document.scrollingElement || document.documentElement || document.body;
  }

  function isNearPageBottom(settings) {
    const scrollEl = getScrollElement();
    const scrollTop = window.scrollY || scrollEl.scrollTop || 0;
    const clientHeight = window.innerHeight || scrollEl.clientHeight || 0;
    const scrollHeight = Math.max(
      scrollEl.scrollHeight || 0,
      document.body?.scrollHeight || 0,
      document.documentElement?.scrollHeight || 0
    );
    return scrollTop + clientHeight >= scrollHeight - settings.paginationBottomThresholdPx;
  }

  async function scrollDown(settings) {
    window.scrollBy({ top: window.innerHeight * 0.8, behavior: "smooth" });
    await sleep(settings.scrollPauseMs);
  }

  function clickLikeHuman(element) {
    const events = ["mouseover", "mouseenter", "mousedown", "mouseup", "click"];
    for (const eventName of events) {
      try {
        element.dispatchEvent(new MouseEvent(eventName, {
          bubbles: true,
          cancelable: true
        }));
      } catch (_error) {
        // Ignore browser-specific event dispatch differences.
      }
    }
    try {
      element.click();
    } catch (_error) {
      // Ignore fallback click failures.
    }
  }

  function getPaginationRoot() {
    return (
      document.querySelector(".ReviewsPage-Pagination") ||
      document.querySelector(".Pagination.ReviewsPage-Pagination") ||
      Array.from(document.querySelectorAll(".Pagination")).find((element) => (
        Boolean(element.querySelector(".Pagination-Link_selected"))
      )) ||
      null
    );
  }

  async function goToNextPage(settings) {
    if (!settings.paginationEnabled) {
      return false;
    }

    const pagination = getPaginationRoot();
    if (!pagination) {
      return false;
    }

    const allLinks = Array.from(pagination.querySelectorAll(".Pagination-Link"));
    const selected = pagination.querySelector(".Pagination-Link_selected");
    const selectedPage = Number(normalizeText(selected?.innerText || "0"));
    if (!selected || !selectedPage) {
      return false;
    }

    const selectedIndex = allLinks.indexOf(selected);
    const isEnabledPageLink = (link) => {
      const className = String(link.className || "");
      const text = normalizeText(link.innerText);
      return (
        !className.includes("Pagination-Link_selected") &&
        !className.includes("ya-business-link_disabled") &&
        link.getAttribute("aria-disabled") !== "true" &&
        link.getAttribute("disabled") !== "true" &&
        /^\d+$/.test(text)
      );
    };

    let nextLink = allLinks.find((link) => (
      isEnabledPageLink(link) &&
      Number(normalizeText(link.innerText)) === selectedPage + 1
    ));

    if (!nextLink) {
      nextLink = allLinks.find((link, index) => (
        index > selectedIndex &&
        /\.\.\.|…/.test(normalizeText(link.innerText)) &&
        String(link.className || "").includes("ya-business-link_disabled") === false &&
        link.getAttribute("aria-disabled") !== "true"
      ));
    }

    if (!nextLink) {
      nextLink = allLinks.find((link, index) => (
        index > selectedIndex &&
        isEnabledPageLink(link) &&
        Number(normalizeText(link.innerText)) > selectedPage
      ));
    }

    if (!nextLink) {
      return false;
    }

    nextLink.scrollIntoView({ behavior: "smooth", block: "center" });
    await sleep(800);
    clickLikeHuman(nextLink);
    await sleep(settings.paginationWaitMs);
    window.scrollTo({ top: 0, behavior: "smooth" });
    await sleep(settings.scrollPauseMs);
    return true;
  }

  async function runAutoLoop() {
    if (autoLoopRunning) {
      return;
    }

    autoLoopRunning = true;
    autoLoopStopRequested = false;

    try {
      while (!autoLoopStopRequested) {
        const settings = await getAutoSettings();
        if (!settings.autoModeEnabled) {
          break;
        }

        const storageKeys = getStateStorageKeys(settings.accountId);
        const syncedSet = loadSetFromStorage(storageKeys.synced);
        const publishedSet = loadSetFromStorage(storageKeys.published);

        try {
          await syncVisibleReviewsAuto(settings, syncedSet);
          saveSetToStorage(storageKeys.synced, syncedSet);

          const published = await publishNextApprovedAuto(settings, publishedSet);
          if (published) {
            saveSetToStorage(storageKeys.published, publishedSet);
            continue;
          }

          await scrollDown(settings);
          if (isNearPageBottom(settings)) {
            await goToNextPage(settings);
          }
        } catch (error) {
          console.error("[reviews-auto-loop]", error);
        }

        await sleep(settings.scanIntervalMs);
      }
    } finally {
      autoLoopRunning = false;
      autoLoopStopRequested = false;
    }
  }

  async function syncAutoLoopState() {
    const settings = await getAutoSettings();
    if (settings.autoModeEnabled) {
      runAutoLoop().catch((error) => console.error("[reviews-auto-loop]", error));
      return;
    }
    autoLoopStopRequested = true;
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes[SETTINGS_KEY]) {
      return;
    }
    syncAutoLoopState().catch((error) => console.error("[reviews-auto-loop]", error));
  });

  syncAutoLoopState().catch((error) => console.error("[reviews-auto-loop]", error));
})();
