from uuid import uuid4

from apps.backend.app.config.settings import Settings
from apps.backend.app.services.queue_service import QueueService


def test_queue_service_skips_enqueue_when_database_transport_enabled() -> None:
    settings = Settings(queue_transport="database")
    service = QueueService(settings)

    enqueued = service.enqueue_ai_job(uuid4())

    assert enqueued is False
