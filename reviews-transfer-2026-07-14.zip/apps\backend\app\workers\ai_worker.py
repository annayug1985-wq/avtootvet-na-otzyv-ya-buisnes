from __future__ import annotations

import argparse
import time
from uuid import UUID

from sqlalchemy.orm import Session, sessionmaker

from apps.backend.app.config.settings import get_settings
from apps.backend.app.db.session import SessionLocal
from apps.backend.app.providers.base import BaseAiProvider
from apps.backend.app.repositories.ai_task_repository import AiTaskRepository
from apps.backend.app.repositories.moderation_repository import ModerationRepository
from apps.backend.app.repositories.review_repository import ReviewRepository
from apps.backend.app.services.ai_service import AiService
from apps.backend.app.services.queue_service import QueueService
from apps.backend.app.utils import configure_logging, get_logger

settings = get_settings()
configure_logging(settings.log_level)
logger = get_logger("reviews.ai_worker")


def process_ai_job(
    job_id: UUID,
    *,
    db: Session,
    provider: BaseAiProvider | None = None,
) -> None:
    moderation_repository = ModerationRepository(db)
    review_repository = ReviewRepository(db)
    ai_task_repository = AiTaskRepository(db)

    job = moderation_repository.get(job_id)
    if job is None:
        raise ValueError(f"Moderation job {job_id} not found")

    review = review_repository.get(job.review_id)
    if review is None:
        raise ValueError(f"Review {job.review_id} not found")

    task = ai_task_repository.enqueue(job.id)
    task.status = "processing"
    task.attempt_count += 1
    task.last_error = None
    db.flush()

    try:
        logger.info("ai_generation_started", extra={"job_id": job.id, "review_id": review.id, "attempt_count": task.attempt_count})
        ai_service = AiService(db, provider=provider)
        reply = ai_service.generate_reply_for(review=review, job=job)
        moderation_repository.update_generated_reply(job, reply=reply, status="pending_review")
        review.status = "pending_review"
        task.status = "done"
        db.commit()
        logger.info("ai_generation_completed", extra={"job_id": job.id, "review_id": review.id})
        QueueService(settings).enqueue_telegram_job(job.id)
    except Exception as exc:
        job.status = "failed"
        review.status = "failed"
        task.status = "failed"
        task.last_error = str(exc)
        db.commit()
        logger.exception("ai_generation_failed", extra={"job_id": job.id, "review_id": review.id})
        raise


def process_next_ai_task(
    *,
    db: Session,
    provider: BaseAiProvider | None = None,
) -> UUID | None:
    task = AiTaskRepository(db).get_next_pending()
    if task is None:
        return None
    process_ai_job(task.job_id, db=db, provider=provider)
    return task.job_id


def run_ai_job(job_id: str) -> None:
    db = SessionLocal()
    try:
        process_ai_job(UUID(job_id), db=db)
    finally:
        db.close()


def run_pending_jobs(
    *,
    session_factory: sessionmaker = SessionLocal,
    provider: BaseAiProvider | None = None,
    limit: int = 1,
) -> int:
    processed = 0
    for _ in range(limit):
        db = session_factory()
        try:
            job_id = process_next_ai_task(db=db, provider=provider)
            if job_id is None:
                break
            processed += 1
        finally:
            db.close()
    return processed


def run_forever(
    *,
    session_factory: sessionmaker = SessionLocal,
    provider: BaseAiProvider | None = None,
    limit: int = 10,
    poll_interval_seconds: float | None = None,
) -> None:
    interval = settings.worker_poll_interval_seconds if poll_interval_seconds is None else poll_interval_seconds
    while True:
        processed = run_pending_jobs(session_factory=session_factory, provider=provider, limit=limit)
        if processed == 0:
            logger.info("worker_idle", extra={"poll_interval_seconds": interval})
            time.sleep(interval)


def main() -> int:
    parser = argparse.ArgumentParser(description="Process queued AI moderation jobs.")
    parser.add_argument("--job-id", help="Process a specific moderation job id.")
    parser.add_argument("--limit", type=int, default=1, help="Maximum number of queued jobs to process.")
    parser.add_argument("--forever", action="store_true", help="Keep polling for new queued jobs.")
    parser.add_argument("--poll-interval", type=float, default=None, help="Seconds to sleep when no tasks are available.")
    args = parser.parse_args()

    if args.job_id:
        db = SessionLocal()
        try:
            process_ai_job(UUID(args.job_id), db=db)
        finally:
            db.close()
        return 0

    if args.forever:
        run_forever(limit=args.limit, poll_interval_seconds=args.poll_interval)
        return 0

    run_pending_jobs(limit=args.limit)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
