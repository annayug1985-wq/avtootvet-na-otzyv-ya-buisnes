const statusNode = document.getElementById("status");
const backendBaseUrlNode = document.getElementById("backendBaseUrl");
const accountIdNode = document.getElementById("accountId");
const autoModeEnabledNode = document.getElementById("autoModeEnabled");

document.getElementById("saveSettings").addEventListener("click", async () => {
  await runAction("save settings", () => chrome.runtime.sendMessage({
    type: "SAVE_SETTINGS",
    settings: getFormSettings()
  }));
});

autoModeEnabledNode.addEventListener("change", async () => {
  const response = await chrome.runtime.sendMessage({
    type: "SAVE_SETTINGS",
    settings: getFormSettings()
  });

  if (!response.ok) {
    render({ error: response.error });
    return;
  }

  render({
    message: `Автопубликация ${autoModeEnabledNode.checked ? "включена" : "выключена"}.`
  });
});

document.getElementById("checkHealth").addEventListener("click", async () => {
  await runAction("проверка backend", () => chrome.runtime.sendMessage({ type: "CHECK_HEALTH" }));
});

document.getElementById("collectPage").addEventListener("click", async () => {
  await runAction("сбор отзывов со страницы", () => chrome.runtime.sendMessage({ type: "COLLECT_CURRENT_PAGE" }));
});

document.getElementById("refreshStatuses").addEventListener("click", async () => {
  await runAction("обновление статусов", () => chrome.runtime.sendMessage({ type: "REFRESH_STATUSES" }));
});

document.getElementById("publishApproved").addEventListener("click", async () => {
  await runAction("публикация согласованных ответов", () => chrome.runtime.sendMessage({ type: "PUBLISH_APPROVED" }));
});

init().catch((error) => render(error));

async function init() {
  const settingsResponse = await chrome.runtime.sendMessage({ type: "GET_SETTINGS" });
  if (!settingsResponse.ok) {
    throw new Error(settingsResponse.error);
  }
  backendBaseUrlNode.value = settingsResponse.settings.backendBaseUrl || "";
  accountIdNode.value = settingsResponse.settings.accountId || "";
  autoModeEnabledNode.checked = Boolean(settingsResponse.settings.autoModeEnabled);

  const syncResponse = await chrome.runtime.sendMessage({ type: "GET_LAST_SYNC" });
  if (syncResponse.ok && syncResponse.lastSync) {
    render(syncResponse.lastSync);
  } else {
    render({ message: "Готово. Открой страницу отзывов в Яндекс Бизнес и нажми «Собрать отзывы»." });
  }
}

async function runAction(label, action) {
  render({ message: `Выполняется: ${label}...` });
  const response = await action();
  if (!response.ok) {
    render({ error: response.error });
    return;
  }
  render(response);
}

function getFormSettings() {
  return {
    backendBaseUrl: backendBaseUrlNode.value.trim(),
    accountId: accountIdNode.value.trim(),
    autoModeEnabled: autoModeEnabledNode.checked
  };
}

function render(data) {
  statusNode.textContent = JSON.stringify(data, null, 2);
}
