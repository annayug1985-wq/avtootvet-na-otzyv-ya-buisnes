from __future__ import annotations

from apps.backend.app.providers.base import BaseAiProvider
from apps.backend.app.workers.ai_worker import process_next_ai_task


class FakeProvider(BaseAiProvider):
    def generate_reply(
        self,
        *,
        review_text: str,
        rating: int,
        prompt: str,
        examples: list[dict[str, str | int | None]],
        previous_reply: str | None = None,
    ) -> str:
        return "Спасибо за отзыв!"


def test_next_approved_endpoint_returns_first_approved_reply(client, db_session) -> None:
    response = client.post(
        "/api/reviews",
        json={
            "accountId": "account_1",
            "rating": 5,
            "author": "Иван",
            "date": "2026-06-18",
            "address": "Москва",
            "reviewText": "Все отлично",
            "pageUrl": "https://example.com/review/1",
        },
    )
    assert response.status_code == 201
    payload = response.json()

    process_next_ai_task(db=db_session, provider=FakeProvider())

    approve_response = client.post(
        "/api/telegram/webhook",
        json={
            "update_id": 3001,
            "callback_query": {
                "id": "cbq-approved",
                "from": {"id": 17, "username": "moderator"},
                "data": f"approve:{payload['jobId']}",
            },
        },
    )
    assert approve_response.status_code == 200

    next_approved_response = client.get("/api/reviews/next-approved", params={"accountId": "account_1"})
    assert next_approved_response.status_code == 200
    assert next_approved_response.json() == {
        "ok": True,
        "review": {
            "id": payload["reviewId"],
            "reviewId": payload["reviewId"],
            "reviewKey": next_approved_response.json()["review"]["reviewKey"],
            "stars": 5,
            "author": "Иван",
            "date": "2026-06-18",
            "address": "Москва",
            "reviewText": "Все отлично",
            "reply": "Спасибо за отзыв!",
        },
    }
