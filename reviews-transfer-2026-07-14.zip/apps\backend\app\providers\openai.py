from __future__ import annotations

import json
from urllib import request
from urllib.error import HTTPError, URLError

from apps.backend.app.config.settings import Settings
from apps.backend.app.providers.base import (
    AiProviderAuthError,
    AiProviderRateLimitError,
    AiProviderResponseError,
    AiProviderTransientError,
    BaseAiProvider,
)
from apps.backend.app.utils import call_with_retry, get_logger


class OpenAIProvider(BaseAiProvider):
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.logger = get_logger("reviews.ai.openai")

    def generate_reply(
        self,
        *,
        review_text: str,
        rating: int,
        prompt: str,
        examples: list[dict[str, str | int | None]],
        previous_reply: str | None = None,
    ) -> str:
        if not self.settings.openai_api_key:
            raise AiProviderAuthError("OPENAI_API_KEY is not configured")

        payload = {
            "model": self.settings.openai_model,
            "messages": [{"role": "user", "content": prompt}],
        }
        body = json.dumps(payload).encode("utf-8")
        req = request.Request(
            url=f"{self.settings.openai_api_base.rstrip('/')}/chat/completions",
            data=body,
            headers={
                "Authorization": f"Bearer {self.settings.openai_api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        def do_request():
            try:
                with request.urlopen(req, timeout=self.settings.ollama_timeout_seconds) as response:
                    return json.loads(response.read().decode("utf-8"))
            except HTTPError as exc:
                if exc.code in {401, 403}:
                    raise AiProviderAuthError("OpenAI authentication failed") from exc
                if exc.code == 429:
                    raise AiProviderRateLimitError("OpenAI rate limit") from exc
                if exc.code >= 500:
                    raise AiProviderTransientError("OpenAI upstream error") from exc
                raise AiProviderResponseError(f"OpenAI request failed with {exc.code}") from exc
            except URLError as exc:
                raise AiProviderTransientError("OpenAI network error") from exc

        data = call_with_retry(
            do_request,
            attempts=self.settings.external_request_max_retries + 1,
            backoff_seconds=self.settings.external_request_backoff_seconds,
            retry_on=(AiProviderTransientError, AiProviderRateLimitError),
            logger=self.logger,
            operation_name="openai_generate",
            context={"model": self.settings.openai_model},
        )
        reply = str(data.get("choices", [{}])[0].get("message", {}).get("content", "")).strip()
        if not reply:
            raise AiProviderResponseError("OpenAI returned an empty response")
        return reply
