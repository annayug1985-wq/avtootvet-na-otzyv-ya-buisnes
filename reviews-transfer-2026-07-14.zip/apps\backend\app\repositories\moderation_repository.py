from sqlalchemy import exists, select
from sqlalchemy.orm import Session

from apps.backend.app.db.models.moderation_job import ModerationJob
from apps.backend.app.db.models.review import Review
from apps.backend.app.db.models.telegram_event import TelegramEvent


class ModerationRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get_by_review_id(self, review_id) -> ModerationJob | None:
        return self.db.scalar(select(ModerationJob).where(ModerationJob.review_id == review_id))

    def get(self, job_id) -> ModerationJob | None:
        return self.db.get(ModerationJob, job_id)

    def has_active_delivery_for_account(self, account_id: str) -> bool:
        sent_exists = exists(
            select(TelegramEvent.id).where(
                TelegramEvent.job_id == ModerationJob.id,
                TelegramEvent.action == "sent_for_moderation",
            )
        )
        statement = (
            select(ModerationJob.id)
            .join(Review, Review.id == ModerationJob.review_id)
            .where(
                Review.account_id == account_id,
                ModerationJob.status == "pending_review",
                sent_exists,
            )
            .limit(1)
        )
        return self.db.scalar(statement) is not None

    def get_next_pending_for_account(self, account_id: str) -> ModerationJob | None:
        sent_exists = exists(
            select(TelegramEvent.id).where(
                TelegramEvent.job_id == ModerationJob.id,
                TelegramEvent.action == "sent_for_moderation",
            )
        )
        statement = (
            select(ModerationJob)
            .join(Review, Review.id == ModerationJob.review_id)
            .where(
                Review.account_id == account_id,
                ModerationJob.status == "pending_review",
                ModerationJob.generated_reply.is_not(None),
                ~sent_exists,
            )
            .order_by(ModerationJob.created_at.asc())
            .limit(1)
        )
        return self.db.scalar(statement)

    def update_generated_reply(self, job: ModerationJob, *, reply: str, status: str) -> ModerationJob:
        job.generated_reply = reply
        job.status = status
        self.db.add(job)
        self.db.flush()
        return job

    def update_approved_reply(
        self,
        job: ModerationJob,
        *,
        reply: str,
        approved_by: str | None,
        status: str,
    ) -> ModerationJob:
        job.approved_reply = reply
        job.approved_by = approved_by
        job.status = status
        self.db.add(job)
        self.db.flush()
        return job

    def update_status(self, job: ModerationJob, *, status: str) -> ModerationJob:
        job.status = status
        self.db.add(job)
        self.db.flush()
        return job

    def add(self, job: ModerationJob) -> ModerationJob:
        self.db.add(job)
        self.db.flush()
        return job
