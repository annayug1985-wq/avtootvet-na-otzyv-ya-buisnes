from __future__ import annotations

import argparse
import json
from urllib import parse, request
from urllib.error import HTTPError

from apps.backend.app.config.settings import get_settings

ALLOWED_UPDATES = ("message", "callback_query")


def build_webhook_url(base_url: str) -> str:
    normalized = base_url.rstrip("/")
    if not normalized.startswith("https://"):
        raise ValueError("APP_BASE_URL must start with https:// before registering a Telegram webhook")
    return f"{normalized}/api/telegram/webhook"


def telegram_api(method: str, payload: dict[str, str]) -> dict:
    settings = get_settings()
    if not settings.telegram_bot_token:
        raise ValueError("TELEGRAM_BOT_TOKEN is not configured")

    body = parse.urlencode(payload).encode("utf-8")
    endpoint = f"{settings.telegram_api_base.rstrip('/')}/bot{settings.telegram_bot_token}/{method}"
    req = request.Request(endpoint, data=body, method="POST")
    try:
        with request.urlopen(req, timeout=settings.telegram_timeout_seconds) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        details = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Telegram API {method} failed with HTTP {exc.code}: {details}") from exc


def set_webhook() -> dict:
    settings = get_settings()
    webhook_url = build_webhook_url(settings.app_base_url)
    return telegram_api(
        "setWebhook",
        {
            "url": webhook_url,
            # Telegram keeps the previous allowed_updates filter if it is omitted.
            # Register both message and callback_query explicitly so inline buttons
            # continue to reach the backend after tunnel or webhook resets.
            "allowed_updates": json.dumps(list(ALLOWED_UPDATES)),
        },
    )


def get_webhook_info() -> dict:
    return telegram_api("getWebhookInfo", {})


def delete_webhook() -> dict:
    return telegram_api("deleteWebhook", {})


def main() -> int:
    parser = argparse.ArgumentParser(description="Manage the Telegram webhook for the reviews backend.")
    parser.add_argument("action", choices=("set", "info", "delete"))
    args = parser.parse_args()

    if args.action == "set":
        result = set_webhook()
    elif args.action == "info":
        result = get_webhook_info()
    else:
        result = delete_webhook()

    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
