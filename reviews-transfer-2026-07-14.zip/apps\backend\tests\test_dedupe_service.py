from apps.backend.app.services.dedupe_service import build_review_key, normalize_text


def test_normalize_text_collapses_whitespace_and_case() -> None:
    assert normalize_text("  Привет   Мир \n") == "привет мир"


def test_build_review_key_is_stable_for_equivalent_text() -> None:
    left = build_review_key(
        account_id="a1",
        rating=5,
        author="Ivan",
        review_date="2026-06-18",
        address="Moscow",
        review_text="Все   отлично",
    )
    right = build_review_key(
        account_id="a1",
        rating=5,
        author="Ivan",
        review_date="2026-06-18",
        address="Moscow",
        review_text=" все отлично ",
    )
    assert left == right
