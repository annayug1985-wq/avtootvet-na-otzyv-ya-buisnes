from uuid import UUID

from pydantic import BaseModel, Field


class ReviewCreateRequest(BaseModel):
    accountId: str = Field(min_length=1)
    rating: int = Field(ge=1, le=5)
    author: str | None = None
    date: str | None = None
    address: str | None = None
    reviewText: str = Field(min_length=1)
    pageUrl: str | None = None
    source: str = "browser"


class ReviewCreateResponse(BaseModel):
    ok: bool
    reviewId: UUID
    jobId: UUID
    status: str
    duplicate: bool


class ReviewPublishedRequest(BaseModel):
    published: bool


class ReviewPublishedResponse(BaseModel):
    ok: bool
    reviewId: UUID
    jobId: UUID
    status: str


class NextApprovedReviewPayload(BaseModel):
    id: UUID
    reviewId: UUID
    reviewKey: str
    stars: int
    author: str | None = None
    date: str | None = None
    address: str | None = None
    reviewText: str
    reply: str


class NextApprovedReviewResponse(BaseModel):
    ok: bool
    review: NextApprovedReviewPayload | None
