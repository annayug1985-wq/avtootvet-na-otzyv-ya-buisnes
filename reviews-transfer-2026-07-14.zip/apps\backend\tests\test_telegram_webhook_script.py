from __future__ import annotations

from types import SimpleNamespace

from apps.backend.app.scripts import telegram_webhook


def test_set_webhook_registers_callback_updates(monkeypatch) -> None:
    captured: dict[str, object] = {}

    monkeypatch.setattr(
        telegram_webhook,
        "get_settings",
        lambda: SimpleNamespace(app_base_url="https://example.test"),
    )

    def fake_telegram_api(method: str, payload: dict[str, str]) -> dict[str, object]:
        captured["method"] = method
        captured["payload"] = payload
        return {"ok": True}

    monkeypatch.setattr(telegram_webhook, "telegram_api", fake_telegram_api)

    result = telegram_webhook.set_webhook()

    assert result == {"ok": True}
    assert captured["method"] == "setWebhook"
    assert captured["payload"] == {
        "url": "https://example.test/api/telegram/webhook",
        "allowed_updates": '["message", "callback_query"]',
    }
