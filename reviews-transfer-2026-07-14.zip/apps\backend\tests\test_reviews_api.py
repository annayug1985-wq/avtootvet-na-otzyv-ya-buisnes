from uuid import UUID

from sqlalchemy import select

from apps.backend.app.db.models.ai_task import AiTask
from apps.backend.app.db.models.approved_example import ApprovedExample
from apps.backend.app.db.models.telegram_event import TelegramEvent
from apps.backend.app.providers.base import BaseAiProvider
from apps.backend.app.repositories.moderation_repository import ModerationRepository
from apps.backend.app.workers.ai_worker import process_next_ai_task


class FakeProvider(BaseAiProvider):
    def generate_reply(
        self,
        *,
        review_text: str,
        rating: int,
        prompt: str,
        examples: list[dict[str, str | int | None]],
        previous_reply: str | None = None,
    ) -> str:
        return "Спасибо за отзыв!"


class FailingProvider(BaseAiProvider):
    def generate_reply(
        self,
        *,
        review_text: str,
        rating: int,
        prompt: str,
        examples: list[dict[str, str | int | None]],
        previous_reply: str | None = None,
    ) -> str:
        raise RuntimeError("temporary ai failure")


def create_approved_review(client, db_session) -> tuple[str, str]:
    response = client.post(
        "/api/reviews",
        json={
            "accountId": "account_1",
            "rating": 5,
            "author": "Иван",
            "date": "2026-06-18",
            "address": "Москва",
            "reviewText": "Все отлично",
            "pageUrl": "https://example.com/review/1",
        },
    )
    assert response.status_code == 201
    payload = response.json()
    process_next_ai_task(db=db_session, provider=FakeProvider())
    approve_response = client.post(
        "/api/telegram/webhook",
        json={
            "update_id": 2001,
            "callback_query": {
                "id": "cbq-approved",
                "from": {"id": 17, "username": "moderator"},
                "data": f"approve:{payload['jobId']}",
            },
        },
    )
    assert approve_response.status_code == 200
    return payload["reviewId"], payload["jobId"]


def test_create_review_and_return_job(client) -> None:
    response = client.post(
        "/api/reviews",
        json={
            "accountId": "account_1",
            "rating": 5,
            "author": "Иван",
            "date": "2026-06-18",
            "address": "Москва",
            "reviewText": "Все отлично",
            "pageUrl": "https://example.com/review/1",
        },
    )
    assert response.status_code == 201
    data = response.json()
    assert data["ok"] is True
    assert data["duplicate"] is False
    assert data["status"] == "generating"

    job_response = client.get(f"/api/jobs/{data['jobId']}")
    assert job_response.status_code == 200
    assert job_response.json()["status"] == "generating"
    assert job_response.headers["x-request-id"]


def test_duplicate_review_returns_existing_ids(client) -> None:
    payload = {
        "accountId": "account_1",
        "rating": 5,
        "author": "Иван",
        "date": "2026-06-18",
        "address": "Москва",
        "reviewText": "Все отлично",
        "pageUrl": "https://example.com/review/1",
    }
    first = client.post("/api/reviews", json=payload)
    second = client.post("/api/reviews", json={**payload, "reviewText": "  Все   отлично  "})

    assert first.status_code == 201
    assert second.status_code == 201
    assert second.json()["duplicate"] is True
    assert second.json()["reviewId"] == first.json()["reviewId"]
    assert second.json()["jobId"] == first.json()["jobId"]


def test_ignored_review_is_requeued_on_recollect(client, db_session) -> None:
    payload = {
        "accountId": "account_1",
        "rating": 5,
        "author": "Иван",
        "date": "2026-06-18",
        "address": "Москва",
        "reviewText": "Все отлично",
        "pageUrl": "https://example.com/review/1",
    }
    first = client.post("/api/reviews", json=payload)
    assert first.status_code == 201

    job_id = first.json()["jobId"]
    process_next_ai_task(db=db_session, provider=FakeProvider())

    job = ModerationRepository(db_session).get(UUID(job_id))
    assert job is not None
    job.status = "ignored"
    db_session.flush()

    second = client.post("/api/reviews", json=payload)

    assert second.status_code == 201
    assert second.json()["duplicate"] is False
    assert second.json()["reviewId"] == first.json()["reviewId"]
    assert second.json()["jobId"] == first.json()["jobId"]
    assert second.json()["status"] == "generating"

    db_session.refresh(job)
    assert job.status == "generating"

    task = db_session.scalar(select(AiTask).where(AiTask.job_id == UUID(job_id)))
    assert task is not None
    assert task.status == "pending"
    assert task.last_error is None

    sent_event = db_session.scalar(
        select(TelegramEvent).where(
            TelegramEvent.job_id == UUID(job_id),
            TelegramEvent.action == "sent_for_moderation",
        )
    )
    assert sent_event is None


def test_job_reply_is_available_only_after_approval(client, db_session) -> None:
    review_id, job_id = create_approved_review(client, db_session)

    job_response = client.get(f"/api/jobs/{job_id}")

    assert job_response.status_code == 200
    assert job_response.json() == {
        "ok": True,
        "jobId": job_id,
        "status": "approved",
        "reply": "Спасибо за отзыв!",
    }


def test_publish_endpoint_marks_job_as_published_and_stores_example(client, db_session) -> None:
    review_id, job_id = create_approved_review(client, db_session)

    response = client.post(f"/api/reviews/{review_id}/published", json={"published": True})

    assert response.status_code == 200
    assert response.json() == {
        "ok": True,
        "reviewId": review_id,
        "jobId": job_id,
        "status": "published",
    }

    job = ModerationRepository(db_session).get(UUID(job_id))
    assert job is not None
    assert job.status == "published"

    example = db_session.scalar(select(ApprovedExample))
    assert example is not None
    assert example.review_text == "Все отлично"
    assert example.answer_text == "Спасибо за отзыв!"
    assert example.rating == 5


def test_publish_endpoint_rejects_unapproved_review(client, db_session) -> None:
    response = client.post(
        "/api/reviews",
        json={
            "accountId": "account_1",
            "rating": 5,
            "author": "Иван",
            "date": "2026-06-18",
            "address": "Москва",
            "reviewText": "Все отлично",
            "pageUrl": "https://example.com/review/1",
        },
    )
    assert response.status_code == 201

    review_id = response.json()["reviewId"]
    publish_response = client.post(f"/api/reviews/{review_id}/published", json={"published": True})

    assert publish_response.status_code == 409


def test_retry_endpoint_requeues_failed_job(client, db_session) -> None:
    response = client.post(
        "/api/reviews",
        json={
            "accountId": "account_1",
            "rating": 5,
            "author": "РРІР°РЅ",
            "date": "2026-06-18",
            "address": "РњРѕСЃРєРІР°",
            "reviewText": "Р’СЃРµ РѕС‚Р»РёС‡РЅРѕ",
            "pageUrl": "https://example.com/review/1",
        },
    )
    assert response.status_code == 201

    job_id = response.json()["jobId"]
    try:
        process_next_ai_task(db=db_session, provider=FailingProvider())
    except RuntimeError:
        pass

    retry_response = client.post(f"/api/jobs/{job_id}/retry")

    assert retry_response.status_code == 200
    assert retry_response.json() == {
        "ok": True,
        "jobId": job_id,
        "status": "generating",
        "reply": None,
    }

    job = ModerationRepository(db_session).get(UUID(job_id))
    assert job is not None
    assert job.status == "generating"

    task = db_session.scalar(select(AiTask).where(AiTask.job_id == UUID(job_id)))
    assert task is not None
    assert task.status == "pending"
    assert task.last_error is None


def test_retry_endpoint_rejects_non_failed_job(client, db_session) -> None:
    _, job_id = create_approved_review(client, db_session)

    retry_response = client.post(f"/api/jobs/{job_id}/retry")

    assert retry_response.status_code == 409


def test_full_review_workflow_happy_path(client, db_session) -> None:
    review_id, job_id = create_approved_review(client, db_session)

    approved_job_response = client.get(f"/api/jobs/{job_id}")
    assert approved_job_response.status_code == 200
    assert approved_job_response.json()["status"] == "approved"
    assert approved_job_response.json()["reply"] == "Спасибо за отзыв!"

    publish_response = client.post(f"/api/reviews/{review_id}/published", json={"published": True})
    assert publish_response.status_code == 200
    assert publish_response.json()["status"] == "published"

    repeated_publish_response = client.post(f"/api/reviews/{review_id}/published", json={"published": True})
    assert repeated_publish_response.status_code == 200
    assert repeated_publish_response.json()["status"] == "published"

    published_job_response = client.get(f"/api/jobs/{job_id}")
    assert published_job_response.status_code == 200
    assert published_job_response.json()["status"] == "published"
    assert published_job_response.json()["reply"] == "Спасибо за отзыв!"
