"""initial schema"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


revision = "20260618_0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "approved_examples",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("review_text", sa.Text(), nullable=False),
        sa.Column("answer_text", sa.Text(), nullable=False),
        sa.Column("rating", sa.Integer(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "reviews",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("review_key", sa.String(length=64), nullable=False),
        sa.Column("source", sa.String(length=32), nullable=False),
        sa.Column("account_id", sa.String(length=255), nullable=False),
        sa.Column("author", sa.String(length=255), nullable=True),
        sa.Column("rating", sa.Integer(), nullable=False),
        sa.Column("review_text", sa.Text(), nullable=False),
        sa.Column("address", sa.String(length=512), nullable=True),
        sa.Column("review_date", sa.String(length=255), nullable=True),
        sa.Column("page_url", sa.String(length=2048), nullable=True),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("review_key"),
    )
    op.create_index("ix_reviews_account_id", "reviews", ["account_id"])
    op.create_index("ix_reviews_status", "reviews", ["status"])
    op.create_table(
        "moderation_jobs",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("review_id", sa.Uuid(), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("generated_reply", sa.Text(), nullable=True),
        sa.Column("approved_reply", sa.Text(), nullable=True),
        sa.Column("rewrite_count", sa.Integer(), nullable=False),
        sa.Column("approved_by", sa.String(length=255), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["review_id"], ["reviews.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_moderation_jobs_status", "moderation_jobs", ["status"])
    op.create_table(
        "telegram_events",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("telegram_update_id", sa.String(length=255), nullable=True),
        sa.Column("job_id", sa.Uuid(), nullable=True),
        sa.Column("action", sa.String(length=64), nullable=False),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["job_id"], ["moderation_jobs.id"], ondelete="SET NULL"),
        sa.PrimaryKeyConstraint("id"),
    )


def downgrade() -> None:
    op.drop_table("telegram_events")
    op.drop_index("ix_moderation_jobs_status", table_name="moderation_jobs")
    op.drop_table("moderation_jobs")
    op.drop_index("ix_reviews_status", table_name="reviews")
    op.drop_index("ix_reviews_account_id", table_name="reviews")
    op.drop_table("reviews")
    op.drop_table("approved_examples")
