from __future__ import annotations

from uuid import UUID

from apps.backend.app.config.settings import get_settings
from apps.backend.app.providers.base import BaseAiProvider
from apps.backend.app.services.telegram_service import TelegramService
from apps.backend.app.workers.ai_worker import process_next_ai_task


class FakeProvider(BaseAiProvider):
    def generate_reply(
        self,
        *,
        review_text: str,
        rating: int,
        prompt: str,
        examples: list[dict[str, str | int | None]],
        previous_reply: str | None = None,
    ) -> str:
        return "Черновик ответа"


def create_pending_review(client, db_session, *, review_text: str) -> UUID:
    response = client.post(
        "/api/reviews",
        json={
            "accountId": "account_1",
            "rating": 5,
            "author": "Иван",
            "date": "2026-06-18",
            "address": "Москва",
            "reviewText": review_text,
            "pageUrl": "https://example.com/review/1",
        },
    )
    assert response.status_code == 201
    job_id = UUID(response.json()["jobId"])
    process_next_ai_task(db=db_session, provider=FakeProvider())
    return job_id


def test_telegram_dispatch_waits_for_continue_button(client, db_session, monkeypatch) -> None:
    settings = get_settings()
    old_token = settings.telegram_bot_token
    old_chat_id = settings.telegram_chat_id
    settings.telegram_bot_token = "test-token"
    settings.telegram_chat_id = "123"

    sent_payloads: list[dict[str, object]] = []

    def fake_telegram_api(self, method: str, payload: dict[str, object]) -> dict[str, object]:
        sent_payloads.append({"method": method, "payload": payload})
        return {"ok": True}

    monkeypatch.setattr(TelegramService, "_telegram_api", fake_telegram_api)

    try:
        first_job_id = create_pending_review(client, db_session, review_text="Первый отзыв")
        second_job_id = create_pending_review(client, db_session, review_text="Второй отзыв")

        service = TelegramService(db_session)
        assert service.send_for_moderation(job_id=first_job_id) is True
        assert service.send_for_moderation(job_id=second_job_id) is False

        continue_response = client.post(
            "/api/telegram/webhook",
            json={
                "update_id": 4001,
                "callback_query": {
                    "id": "cbq-continue",
                    "from": {"id": 17, "username": "moderator"},
                    "data": f"mod:approve:{first_job_id}",
                },
            },
        )
        assert continue_response.status_code == 200

        released_response = client.post(
            "/api/telegram/webhook",
            json={
                "update_id": 4002,
                "callback_query": {
                    "id": "cbq-release",
                    "from": {"id": 17, "username": "moderator"},
                    "data": f"mod:continue:{first_job_id}",
                },
            },
        )
        assert released_response.status_code == 200

        moderation_messages = [
            item for item in sent_payloads if item["method"] == "sendMessage" and "Черновик ответа" in str(item["payload"])
        ]
        assert len(moderation_messages) >= 2
        assert "Второй отзыв" in str(moderation_messages[-1]["payload"])
    finally:
        settings.telegram_bot_token = old_token
        settings.telegram_chat_id = old_chat_id


def test_telegram_moderation_message_has_card_sections(client, db_session, monkeypatch) -> None:
    settings = get_settings()
    old_token = settings.telegram_bot_token
    old_chat_id = settings.telegram_chat_id
    settings.telegram_bot_token = "test-token"
    settings.telegram_chat_id = "123"

    sent_payloads: list[dict[str, object]] = []

    def fake_telegram_api(self, method: str, payload: dict[str, object]) -> dict[str, object]:
        sent_payloads.append({"method": method, "payload": payload})
        return {"ok": True}

    monkeypatch.setattr(TelegramService, "_telegram_api", fake_telegram_api)

    try:
        job_id = create_pending_review(client, db_session, review_text="Карточный отзыв для Telegram")
        service = TelegramService(db_session)

        assert service.send_for_moderation(job_id=job_id) is True

        moderation_text = str(sent_payloads[0]["payload"]["text"])
        assert "📝 Отзыв на модерацию" in moderation_text
        assert "💬 Текст отзыва:" in moderation_text
        assert "🤖 Черновик ответа" in moderation_text
        assert "Карточный отзыв для Telegram" in moderation_text
        assert "🔗 Ссылка: https://example.com/review/1" in moderation_text
    finally:
        settings.telegram_bot_token = old_token
        settings.telegram_chat_id = old_chat_id
