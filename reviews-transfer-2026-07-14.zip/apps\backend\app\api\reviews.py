from uuid import UUID

from sqlalchemy.orm import Session

from fastapi import APIRouter, Depends, HTTPException, status

from apps.backend.app.api.dependencies import get_db
from apps.backend.app.schemas.review import (
    NextApprovedReviewResponse,
    ReviewCreateRequest,
    ReviewCreateResponse,
    ReviewPublishedRequest,
    ReviewPublishedResponse,
)
from apps.backend.app.services.review_service import ReviewService

router = APIRouter(prefix="/api/reviews", tags=["reviews"])


@router.post("", response_model=ReviewCreateResponse, status_code=status.HTTP_201_CREATED)
def create_review(payload: ReviewCreateRequest, db: Session = Depends(get_db)) -> ReviewCreateResponse:
    service = ReviewService(db)
    result = service.create_or_get(payload)
    return ReviewCreateResponse(**result)


@router.get("/next-approved", response_model=NextApprovedReviewResponse)
def get_next_approved(accountId: str, db: Session = Depends(get_db)) -> NextApprovedReviewResponse:
    service = ReviewService(db)
    result = service.get_next_approved_for_account(accountId)
    return NextApprovedReviewResponse(**result)


@router.post("/{review_id}/published", response_model=ReviewPublishedResponse)
def mark_review_published(
    review_id: UUID,
    payload: ReviewPublishedRequest,
    db: Session = Depends(get_db),
) -> ReviewPublishedResponse:
    service = ReviewService(db)
    try:
        result = service.mark_review_published(review_id, published=payload.published)
    except LookupError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    except PermissionError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    return ReviewPublishedResponse(**result)
