from __future__ import annotations

from uuid import UUID

from sqlalchemy import select

from apps.backend.app.db.models.ai_task import AiTask
from apps.backend.app.db.models.telegram_event import TelegramEvent
from apps.backend.app.providers.base import BaseAiProvider
from apps.backend.app.repositories.moderation_repository import ModerationRepository
from apps.backend.app.workers.ai_worker import process_next_ai_task


class FakeProvider(BaseAiProvider):
    def generate_reply(
        self,
        *,
        review_text: str,
        rating: int,
        prompt: str,
        examples: list[dict[str, str | int | None]],
        previous_reply: str | None = None,
    ) -> str:
        return "Черновик ответа"


def create_pending_review(client, db_session) -> UUID:
    response = client.post(
        "/api/reviews",
        json={
            "accountId": "account_1",
            "rating": 5,
            "author": "Иван",
            "date": "2026-06-18",
            "address": "Москва",
            "reviewText": "Все отлично",
            "pageUrl": "https://example.com/review/1",
        },
    )
    assert response.status_code == 201
    job_id = UUID(response.json()["jobId"])
    process_next_ai_task(db=db_session, provider=FakeProvider())
    return job_id


def test_telegram_webhook_approve_is_idempotent(client, db_session) -> None:
    job_id = create_pending_review(client, db_session)

    payload = {
        "update_id": 1001,
        "callback_query": {
            "id": "cbq-1",
            "from": {"id": 7, "username": "moderator"},
            "data": f"approve:{job_id}",
        },
    }

    first_response = client.post("/api/telegram/webhook", json=payload)
    second_response = client.post("/api/telegram/webhook", json=payload)

    assert first_response.status_code == 200
    assert second_response.status_code == 200

    job = ModerationRepository(db_session).get(job_id)
    assert job is not None
    assert job.status == "approved"
    assert job.approved_reply == "Черновик ответа"
    assert job.approved_by == "moderator"

    events = db_session.scalars(select(TelegramEvent)).all()
    assert len(events) == 1
    assert events[0].action == "approve"
    assert events[0].telegram_update_id == "1001"


def test_telegram_webhook_rewrite_requeues_ai_task(client, db_session) -> None:
    job_id = create_pending_review(client, db_session)

    response = client.post(
        "/api/telegram/webhook",
        json={
            "update_id": 1002,
            "callback_query": {
                "id": "cbq-2",
                "from": {"id": 9, "username": "editor"},
                "data": f"rewrite:{job_id}",
            },
        },
    )

    assert response.status_code == 200

    job = ModerationRepository(db_session).get(job_id)
    assert job is not None
    assert job.status == "generating"
    assert job.rewrite_count == 1

    task = db_session.scalar(select(AiTask).where(AiTask.job_id == job_id))
    assert task is not None
    assert task.status == "pending"

    event = db_session.scalar(select(TelegramEvent).where(TelegramEvent.telegram_update_id == "1002"))
    assert event is not None
    assert event.action == "rewrite"


def test_telegram_webhook_manual_edit_approves_reply(client, db_session) -> None:
    job_id = create_pending_review(client, db_session)

    response = client.post(
        "/api/telegram/webhook",
        json={
            "update_id": 1003,
            "message": {
                "message_id": 55,
                "from": {"id": 11, "username": "lead"},
                "text": f"edit:{job_id} Спасибо за отзыв и доверие!",
            },
        },
    )

    assert response.status_code == 200

    job = ModerationRepository(db_session).get(job_id)
    assert job is not None
    assert job.status == "approved"
    assert job.approved_reply == "Спасибо за отзыв и доверие!"
    assert job.approved_by == "lead"

    event = db_session.scalar(select(TelegramEvent).where(TelegramEvent.telegram_update_id == "1003"))
    assert event is not None
    assert event.action == "edit"


def test_telegram_webhook_stale_rewrite_is_safe_no_op(client, db_session) -> None:
    job_id = create_pending_review(client, db_session)

    approve_response = client.post(
        "/api/telegram/webhook",
        json={
            "update_id": 1004,
            "callback_query": {
                "id": "cbq-approve",
                "from": {"id": 7, "username": "moderator"},
                "data": f"mod:approve:{job_id}",
            },
        },
    )
    assert approve_response.status_code == 200

    rewrite_response = client.post(
        "/api/telegram/webhook",
        json={
            "update_id": 1005,
            "callback_query": {
                "id": "cbq-stale-rewrite",
                "from": {"id": 7, "username": "moderator"},
                "data": f"mod:rewrite:{job_id}",
            },
        },
    )

    assert rewrite_response.status_code == 200

    job = ModerationRepository(db_session).get(job_id)
    assert job is not None
    assert job.status == "approved"


def test_telegram_webhook_edit_button_returns_instruction_mode(client, db_session) -> None:
    job_id = create_pending_review(client, db_session)

    response = client.post(
        "/api/telegram/webhook",
        json={
            "update_id": 1006,
            "callback_query": {
                "id": "cbq-edit",
                "from": {"id": 13, "username": "lead"},
                "data": f"mod:edit:{job_id}",
            },
        },
    )

    assert response.status_code == 200

    event = db_session.scalar(select(TelegramEvent).where(TelegramEvent.telegram_update_id == "1006"))
    assert event is not None
    assert event.action == "edit"

    job = ModerationRepository(db_session).get(job_id)
    assert job is not None
    assert job.status == "pending_review"
